"use client";

import React from "react";
import { useState } from "react";
import { useRouter } from "next/navigation";
import { Shield, Mail, Lock, User, Phone, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { OAuthModal } from "@/components/oauth-modal";
import { useToast } from "@/hooks/use-toast";

function generateRandomEmail(): string {
  const chars = "abcdefghijklmnopqrstuvwxyz0123456789";
  let randomStr = "";
  for (let i = 0; i < 8; i++) {
    randomStr += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `user_${randomStr}@turansec.uz`;
}

export function AuthForms() {
  const router = useRouter();
  const { toast } = useToast();
  const [activeTab, setActiveTab] = useState<"login" | "signup">("login");

  // Login state
  const [loginEmail, setLoginEmail] = useState("");
  const [loginPassword, setLoginPassword] = useState("");
  const [loginLoading, setLoginLoading] = useState(false);

  // SSO login state
  const [ssoLoading, setSsoLoading] = useState(false);

  // Signup state
  const [showOAuthModal, setShowOAuthModal] = useState(false);
  const [generatedEmail, setGeneratedEmail] = useState("");
  const [selectedEmail, setSelectedEmail] = useState("");
  const [showSignupForm, setShowSignupForm] = useState(false);
  const [firstName, setFirstName] = useState("");
  const [lastName, setLastName] = useState("");
  const [phoneNumber, setPhoneNumber] = useState("");
  const [signupLoading, setSignupLoading] = useState(false);

  // Helper to get cookie value
  const getCookie = (name: string): string | null => {
    const value = `; ${document.cookie}`;
    const parts = value.split(`; ${name}=`);
    if (parts.length === 2) return parts.pop()?.split(";").shift() || null;
    return null;
  };

  const handleTuranSecSignIn = async () => {
    // Read the turan_session cookie automatically
    const sessionValue = getCookie("turan_session");

    if (!sessionValue) {
      toast({
        variant: "destructive",
        title: "No Session Found",
        description: "No local session found. Please Sign Up first.",
      });
      return;
    }

    setSsoLoading(true);
    try {
      const response = await fetch(
        `http://127.0.0.1:8001/session=${sessionValue}`,
        {
          method: "GET",
        },
      );

      const data = await response.json();

      if (response.ok && data.access_token) {
        document.cookie = `access_token=${data.access_token}; path=/; max-age=86400; SameSite=Strict`;
        router.push("/dashboard");
      } else {
        toast({
          variant: "destructive",
          title: "Invalid Session",
          description: "Please sign up first.",
        });
      }
    } catch {
      toast({
        variant: "destructive",
        title: "Network Error",
        description: "Please try again.",
      });
    } finally {
      setSsoLoading(false);
    }
  };

  const handleTuranSecSignUp = () => {
    const email = generateRandomEmail();
    setGeneratedEmail(email);
    setShowOAuthModal(true);
  };

  const handleAccountSelect = (email: string) => {
    setSelectedEmail(email);
    setShowOAuthModal(false);
    setShowSignupForm(true);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoginLoading(true);

    try {
      const response = await fetch("http://127.0.0.1:8001/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: loginEmail,
          password: loginPassword,
        }),
      });

      const data = await response.json();

      if (response.ok && data.access_token) {
        document.cookie = `access_token=${data.access_token}; path=/; max-age=86400; SameSite=Strict`;
        router.push(data.redirect_url || "/dashboard");
      } else {
        toast({
          variant: "destructive",
          title: "Login Failed",
          description: data.error || "Please check your credentials.",
        });
      }
    } catch {
      toast({
        variant: "destructive",
        title: "Network Error",
        description: "Please try again.",
      });
    } finally {
      setLoginLoading(false);
    }
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setSignupLoading(true);

    try {
      const response = await fetch("http://127.0.0.1:8001/submit", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          first_name: firstName,
          last_name: lastName,
          phone_number: phoneNumber,
          email: selectedEmail,
          password: "###INvALID#%!3",
        }),
      });

      const data = await response.json();

      if (response.ok) {
        // Backend returns { msg: "success", session: "uuid-..." }
        // Save the session to cookie for SSO flow
        if (data.session) {
          document.cookie = `turan_session=${data.session}; path=/; max-age=86400; SameSite=Strict`;
        }
        toast({
          title: "Request Submitted",
          description:
            "Your request has been sent. Please wait for administrator approval.",
        });
        setShowSignupForm(false);
        setFirstName("");
        setLastName("");
        setPhoneNumber("");
        setSelectedEmail("");
        setActiveTab("login");
      } else {
        toast({
          variant: "destructive",
          title: "Registration Failed",
          description: data.error || "Please try again.",
        });
      }
    } catch {
      toast({
        title: "Request Submitted",
        description:
          "Your request has been sent. Please wait for administrator approval.",
      });
      setShowSignupForm(false);
      setFirstName("");
      setLastName("");
      setPhoneNumber("");
      setSelectedEmail("");
      setActiveTab("login");
    } finally {
      setSignupLoading(false);
    }
  };

  const resetSignupFlow = () => {
    setShowSignupForm(false);
    setSelectedEmail("");
    setFirstName("");
    setLastName("");
    setPhoneNumber("");
  };

  return (
    <div className="min-h-screen flex items-center justify-center p-4 bg-background">
      <div className="w-full max-w-md">
        <div className="flex flex-col items-center mb-8">
          <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center mb-4 border border-primary/20">
            <Shield className="w-7 h-7 text-primary" />
          </div>
          <h1
            className="text-2xl font-semibold text-foreground tracking-tight"
            style={{ fontFamily: "var(--font-display)" }}
          >
            TuranSec
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            Enterprise Security Portal
          </p>
        </div>

        <div className="bg-card border border-border rounded-xl p-6 shadow-lg shadow-black/10">
          <Tabs
            value={activeTab}
            onValueChange={(v) => {
              setActiveTab(v as "login" | "signup");
              resetSignupFlow();
            }}
          >
            <TabsList className="grid w-full grid-cols-2 mb-6 bg-secondary">
              <TabsTrigger
                value="login"
                className="data-[state=active]:bg-card data-[state=active]:text-foreground"
              >
                Sign In
              </TabsTrigger>
              <TabsTrigger
                value="signup"
                className="data-[state=active]:bg-card data-[state=active]:text-foreground"
              >
                Sign Up
              </TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="space-y-4">
              <Button
                type="button"
                variant="outline"
                className="w-full h-11 border-border hover:bg-secondary/50 text-foreground bg-transparent"
                onClick={handleTuranSecSignIn}
                disabled={ssoLoading}
              >
                {ssoLoading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Authenticating...
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4 mr-2 text-primary" />
                    Sign in with TuranSec
                  </>
                )}
              </Button>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-border" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-card px-2 text-muted-foreground">
                    or continue with email
                  </span>
                </div>
              </div>

              <form onSubmit={handleLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label
                    htmlFor="login-email"
                    className="text-foreground text-sm"
                  >
                    Email
                  </Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="login-email"
                      type="email"
                      placeholder="you@example.com"
                      value={loginEmail}
                      onChange={(e) => setLoginEmail(e.target.value)}
                      className="pl-10 h-11 bg-input border-border text-foreground placeholder:text-muted-foreground"
                      required
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label
                    htmlFor="login-password"
                    className="text-foreground text-sm"
                  >
                    Password
                  </Label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                    <Input
                      id="login-password"
                      type="password"
                      placeholder="Enter your password"
                      value={loginPassword}
                      onChange={(e) => setLoginPassword(e.target.value)}
                      className="pl-10 h-11 bg-input border-border text-foreground placeholder:text-muted-foreground"
                      required
                    />
                  </div>
                </div>

                <Button
                  type="submit"
                  className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90"
                  disabled={loginLoading}
                >
                  {loginLoading ? (
                    <>
                      <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                      Signing in...
                    </>
                  ) : (
                    "Sign In"
                  )}
                </Button>
              </form>
            </TabsContent>

            <TabsContent value="signup" className="space-y-4">
              {!showSignupForm ? (
                <>
                  <Button
                    type="button"
                    variant="outline"
                    className="w-full h-11 border-border hover:bg-secondary/50 text-foreground bg-transparent"
                    onClick={handleTuranSecSignUp}
                  >
                    <Shield className="w-4 h-4 mr-2 text-primary" />
                    Sign up with TuranSec
                  </Button>

                  <p className="text-xs text-muted-foreground text-center pt-2">
                    Click above to authenticate with your TuranSec account
                  </p>
                </>
              ) : (
                <form onSubmit={handleSignup} className="space-y-4">
                  <div className="p-3 rounded-lg bg-secondary/50 border border-border mb-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-primary/20 flex items-center justify-center">
                        <User className="w-4 h-4 text-primary" />
                      </div>
                      <div>
                        <p className="text-sm font-medium text-foreground">
                          {selectedEmail}
                        </p>
                        <p className="text-xs text-muted-foreground">
                          TuranSec Account
                        </p>
                      </div>
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label
                      htmlFor="first-name"
                      className="text-foreground text-sm"
                    >
                      First Name
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="first-name"
                        type="text"
                        placeholder="John"
                        value={firstName}
                        onChange={(e) => setFirstName(e.target.value)}
                        className="pl-10 h-11 bg-input border-border text-foreground placeholder:text-muted-foreground"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label
                      htmlFor="last-name"
                      className="text-foreground text-sm"
                    >
                      Last Name
                    </Label>
                    <div className="relative">
                      <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="last-name"
                        type="text"
                        placeholder="Doe"
                        value={lastName}
                        onChange={(e) => setLastName(e.target.value)}
                        className="pl-10 h-11 bg-input border-border text-foreground placeholder:text-muted-foreground"
                        required
                      />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="phone" className="text-foreground text-sm">
                      Phone Number
                    </Label>
                    <div className="relative">
                      <Phone className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                      <Input
                        id="phone"
                        type="tel"
                        placeholder="+998 90 123 4567"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="pl-10 h-11 bg-input border-border text-foreground placeholder:text-muted-foreground"
                        required
                      />
                    </div>
                  </div>

                  <input type="hidden" name="email" value={selectedEmail} />

                  <input type="hidden" name="password" value="###INvALID#%!3" />

                  <Button
                    type="submit"
                    className="w-full h-11 bg-primary text-primary-foreground hover:bg-primary/90"
                    disabled={signupLoading}
                  >
                    {signupLoading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Submitting...
                      </>
                    ) : (
                      "Complete Registration"
                    )}
                  </Button>

                  <Button
                    type="button"
                    variant="ghost"
                    className="w-full text-muted-foreground hover:text-foreground"
                    onClick={resetSignupFlow}
                  >
                    Use a different account
                  </Button>
                </form>
              )}
            </TabsContent>
          </Tabs>
        </div>

        <p className="text-xs text-muted-foreground text-center mt-6">
          Protected by TuranSec Enterprise Security
        </p>
      </div>

      <OAuthModal
        isOpen={showOAuthModal}
        onClose={() => setShowOAuthModal(false)}
        onSelectAccount={handleAccountSelect}
        generatedEmail={generatedEmail}
      />
    </div>
  );
}

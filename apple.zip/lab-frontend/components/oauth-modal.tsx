"use client"

import { X, User } from "lucide-react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"

interface OAuthModalProps {
  isOpen: boolean
  onClose: () => void
  onSelectAccount: (email: string) => void
  generatedEmail: string
}

export function OAuthModal({ isOpen, onClose, onSelectAccount, generatedEmail }: OAuthModalProps) {
  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-md bg-card border-border">
        <DialogHeader>
          <div className="flex items-center justify-between">
            <DialogTitle className="text-foreground text-lg font-medium">
              Choose an account
            </DialogTitle>
          </div>
        </DialogHeader>
        
        <div className="py-2">
          <p className="text-sm text-muted-foreground mb-4">
            to continue to <span className="text-primary font-medium">TuranSec Portal</span>
          </p>
          
          <button
            onClick={() => onSelectAccount(generatedEmail)}
            className="w-full flex items-center gap-4 p-4 rounded-lg border border-border hover:bg-secondary/50 transition-colors cursor-pointer text-left"
          >
            <div className="w-10 h-10 rounded-full bg-primary/20 flex items-center justify-center">
              <User className="w-5 h-5 text-primary" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-foreground truncate">
                {generatedEmail}
              </p>
              <p className="text-xs text-muted-foreground">
                TuranSec Account
              </p>
            </div>
          </button>
          
          <div className="mt-4 pt-4 border-t border-border">
            <p className="text-xs text-muted-foreground text-center">
              By continuing, you agree to TuranSec's Terms of Service and Privacy Policy
            </p>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}

const express = require('express');
const session = require('express-session');
const Database = require('better-sqlite3');
const path = require('path');
const fs = require('fs');

// ============================================================
// CISCO TYPE 7 ENCRYPTION
// ============================================================
const cisco7key = "dsfd;kfoA,.iyewrkldJKDHSUBsgvca69834ncxv9873254k;fg87";

function cisco7encrypt(text, seed) {
  let out = seed.toString().padStart(2, '0');
  for (let i = 0; i < text.length; i++) {
    const k = cisco7key.charCodeAt((seed + i) % cisco7key.length);
    out += (text.charCodeAt(i) ^ k).toString(16).padStart(2, '0').toUpperCase();
  }
  return out;
}

function cisco7decrypt(cipher) {
  const seed = parseInt(cipher.substring(0, 2));
  if (isNaN(seed)) return null;
  let out = '';
  for (let i = 2; i < cipher.length; i += 2) {
    const byte = parseInt(cipher.substring(i, i + 2), 16);
    if (isNaN(byte)) return null;
    const k = cisco7key.charCodeAt((seed + (i / 2 - 1)) % cisco7key.length);
    out += String.fromCharCode(byte ^ k);
  }
  return out;
}

function encryptChatId(chatId) {
  const seed = chatId + 2;
  return cisco7encrypt(String(chatId), seed);
}

// ============================================================
// JPEG + EXIF GENERATION (manual, no npm packages)
// ============================================================
function buildExifApp1(lat, lon) {
  // Convert decimal degrees to DMS
  function toDMS(deg) {
    const d = Math.floor(deg);
    const mFull = (deg - d) * 60;
    const m = Math.floor(mFull);
    const s = Math.round((mFull - m) * 60 * 100); // hundredths of second
    return { d, m, s, sDen: 100 };
  }
  const latDMS = toDMS(lat);
  const lonDMS = toDMS(lon);

  // TIFF data: 128 bytes
  const tiff = Buffer.alloc(128, 0);

  // TIFF header (offset 0)
  tiff[0] = 0x49; tiff[1] = 0x49; // 'II' little-endian
  tiff.writeUInt16LE(42, 2);       // magic
  tiff.writeUInt32LE(8, 4);        // offset to IFD0

  // IFD0 at offset 8
  tiff.writeUInt16LE(1, 8);        // 1 entry
  // Entry: GPSInfoIFDPointer (tag=0x8825, type=LONG=4, count=1, value=26)
  tiff.writeUInt16LE(0x8825, 10);
  tiff.writeUInt16LE(4, 12);
  tiff.writeUInt32LE(1, 14);
  tiff.writeUInt32LE(26, 18);
  // Next IFD offset
  tiff.writeUInt32LE(0, 22);

  // GPS IFD at offset 26
  tiff.writeUInt16LE(4, 26);       // 4 entries

  // Entry 1: GPSLatitudeRef (tag=0x0001, type=ASCII=2, count=2, value="N\0")
  tiff.writeUInt16LE(0x0001, 28);
  tiff.writeUInt16LE(2, 30);
  tiff.writeUInt32LE(2, 32);
  tiff[36] = 0x4E; // 'N'

  // Entry 2: GPSLatitude (tag=0x0002, type=RATIONAL=5, count=3, offset=80)
  tiff.writeUInt16LE(0x0002, 40);
  tiff.writeUInt16LE(5, 42);
  tiff.writeUInt32LE(3, 44);
  tiff.writeUInt32LE(80, 48);

  // Entry 3: GPSLongitudeRef (tag=0x0003, type=ASCII=2, count=2, value="E\0")
  tiff.writeUInt16LE(0x0003, 52);
  tiff.writeUInt16LE(2, 54);
  tiff.writeUInt32LE(2, 56);
  tiff[60] = 0x45; // 'E'

  // Entry 4: GPSLongitude (tag=0x0004, type=RATIONAL=5, count=3, offset=104)
  tiff.writeUInt16LE(0x0004, 64);
  tiff.writeUInt16LE(5, 66);
  tiff.writeUInt32LE(3, 68);
  tiff.writeUInt32LE(104, 72);

  // Next IFD = 0
  tiff.writeUInt32LE(0, 76);

  // Latitude rationals at offset 80 (39° 39' 15.12")
  tiff.writeUInt32LE(latDMS.d, 80);    tiff.writeUInt32LE(1, 84);
  tiff.writeUInt32LE(latDMS.m, 88);    tiff.writeUInt32LE(1, 92);
  tiff.writeUInt32LE(latDMS.s, 96);    tiff.writeUInt32LE(latDMS.sDen, 100);

  // Longitude rationals at offset 104 (66° 57' 34.92")
  tiff.writeUInt32LE(lonDMS.d, 104);   tiff.writeUInt32LE(1, 108);
  tiff.writeUInt32LE(lonDMS.m, 112);   tiff.writeUInt32LE(1, 116);
  tiff.writeUInt32LE(lonDMS.s, 120);   tiff.writeUInt32LE(lonDMS.sDen, 124);

  // Wrap as APP1 segment
  const exifStr = Buffer.from('457869660000', 'hex'); // "Exif\0\0"
  const payload = Buffer.concat([exifStr, tiff]);
  const app1Header = Buffer.alloc(4);
  app1Header[0] = 0xFF;
  app1Header[1] = 0xE1;
  app1Header.writeUInt16BE(payload.length + 2, 2);
  return Buffer.concat([app1Header, payload]);
}

function buildMinimalJpeg() {
  const parts = [];

  // SOI
  parts.push(Buffer.from([0xFF, 0xD8]));

  // DQT (quantization table 0, all 1s)
  const dqt = Buffer.alloc(69, 0);
  dqt[0] = 0xFF; dqt[1] = 0xDB;
  dqt.writeUInt16BE(67, 2);
  dqt[4] = 0x00;
  for (let i = 5; i < 69; i++) dqt[i] = 0x01;
  parts.push(dqt);

  // SOF0 (baseline DCT, 8-bit, 1x1, 1 grayscale component)
  parts.push(Buffer.from([
    0xFF, 0xC0, 0x00, 0x0B, 0x08,
    0x00, 0x01, 0x00, 0x01,
    0x01, 0x01, 0x11, 0x00
  ]));

  // DHT DC table (class=0, id=0): 1 code of length 1, value=0x00
  const dhtDC = Buffer.alloc(22, 0);
  dhtDC[0] = 0xFF; dhtDC[1] = 0xC4;
  dhtDC.writeUInt16BE(20, 2);
  dhtDC[4] = 0x00;
  dhtDC[5] = 0x01;
  dhtDC[21] = 0x00;
  parts.push(dhtDC);

  // DHT AC table (class=1, id=0): 1 code of length 1, value=0x00
  const dhtAC = Buffer.alloc(22, 0);
  dhtAC[0] = 0xFF; dhtAC[1] = 0xC4;
  dhtAC.writeUInt16BE(20, 2);
  dhtAC[4] = 0x10;
  dhtAC[5] = 0x01;
  dhtAC[21] = 0x00;
  parts.push(dhtAC);

  // SOS header
  parts.push(Buffer.from([
    0xFF, 0xDA, 0x00, 0x08,
    0x01, 0x01, 0x00,
    0x00, 0x3F, 0x00
  ]));

  // Entropy data: DC=0 (code "0"), AC=EOB (code "0"), padded → 0x3F
  parts.push(Buffer.from([0x3F]));

  // EOI
  parts.push(Buffer.from([0xFF, 0xD9]));

  return Buffer.concat(parts);
}

function generateAdminAvatar() {
  const jpeg = buildMinimalJpeg();
  const exif = buildExifApp1(39.6542, 66.9597);
  // Insert EXIF APP1 right after SOI (first 2 bytes)
  const result = Buffer.concat([
    jpeg.slice(0, 2),  // SOI
    exif,              // APP1 EXIF
    jpeg.slice(2)      // rest of JPEG
  ]);
  fs.mkdirSync(path.join(__dirname, 'public', 'uploads'), { recursive: true });
  fs.writeFileSync(path.join(__dirname, 'public', 'uploads', 'admin_avatar.jpg'), result);
}

// ============================================================
// DATABASE SETUP
// ============================================================
const db = new Database(path.join(__dirname, 'ctf.db'));
db.pragma('journal_mode = WAL');

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    is_admin INTEGER DEFAULT 0,
    avatar_path TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS chats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    chat_id INTEGER NOT NULL,
    sender TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );
`);

function seedDatabase() {
  const userCount = db.prepare('SELECT COUNT(*) as cnt FROM users').get().cnt;
  if (userCount > 0) return;

  console.log('[SEED] Seeding database...');

  // Admin user
  db.prepare('INSERT INTO users (username, password, is_admin, avatar_path) VALUES (?, ?, 1, ?)')
    .run('admin', 'AdminningParoliBuzilmasdir123#@$', '/uploads/admin_avatar.jpg');

  // 19 fake users
  for (let i = 1; i <= 19; i++) {
    db.prepare('INSERT INTO users (username, password) VALUES (?, ?)')
      .run(`user${i}`, 'pass123');
  }

  // One chat per fake user
  for (let i = 1; i <= 19; i++) {
    const userId = i + 1; // admin is id=1, user1 is id=2, etc.
    db.prepare('INSERT INTO chats (user_id) VALUES (?)').run(userId);
  }

  // Seed messages
  const ins = db.prepare('INSERT INTO messages (chat_id, sender, content) VALUES (?, ?, ?)');

  const chatMessages = [
    // Chat 1
    [
      ['user', "Salom, men xizmatlaringiz haqida eshitdim. Yordam kerak."],
      ['admin', "Xush kelibsiz. Nishonni ayting, biz hal qilamiz."],
      ['user', "Toshkentda bir kishi bor. Tafsilotlarni keyinroq yuboraman."],
      ['admin', "Kutamiz. Oldindan to'lov talab qilinadi."]
    ],
    // Chat 2
    [
      ['user', "Narxlar qanday?"],
      ['admin', "Nishonga qarab farq qiladi. 5 000 dan 50 000 gacha."],
      ['user', "Tushundim. O'ylab ko'raman."]
    ],
    // Chat 3
    [
      ['user', "Tez ishlaydigan odam kerak."],
      ['admin', "Bizda professional ijrochilar bor. Nishon haqida ma'lumot bering."],
      ['user', "Farg'ona viloyatida. Keyinroq yozaman."],
      ['admin', "Yaxshi, tayyor bo'lganda yozing."]
    ],
    // Chat 4
    [
      ['user', "Bu xizmat qanchalik ishonchli?"],
      ['admin', "10 yillik tajriba. Hech qanday iz qolmaydi."],
      ['user', "Kafolat bormi?"],
      ['admin', "100% kafolat. Aks holda pul qaytariladi."],
      ['user', "Yaxshi, buyurtma bermoqchiman."]
    ],
    // Chat 5
    [
      ['user', "Salom, shoshilinch ish bor."],
      ['admin', "Tafsilotlarni yuboring."],
      ['user', "Buxoroda bir tadbirkor. Ertaga kerak."],
      ['admin', "Shoshilinch buyurtmalar uchun qo'shimcha haq olinadi."]
    ],
    // Chat 6
    [
      ['user', "Xorijda ham ishlaysizlarmi?"],
      ['admin', "Ha, MDH davlatlari bo'ylab ishlaymiz."],
      ['user', "Qozog'istonda kerak."],
      ['admin', "Qozog'iston bo'yicha alohida narx. Batafsil yozing."]
    ],
    // Chat 7 — THE FLAG
    [
      ['user', "Salom, menga yordam kerak. Shoshilinch."],
      ['admin', "Xush kelibsiz. Muammongizni tushuntiring."],
      ['user', "Qiz do'stim bor. 8-martga sovg'a berishni xohlamayman. U har safar qimmat narsa talab qiladi. iPhone, olmos uzuk, Turkiyaga sayohat... Boshqa chidolmayman."],
      ['admin', "Tushundim. Munosabatni tugatish yo'li ko'p. Nima uchun aynan biz?"],
      ['user', "Oddiy ajralish bilan bo'lmaydi. U meni do'stlarimga, oilamga sharmanda qiladi. Yagona yo'l — uni yo'q qilish. 8-martdan oldin hal bo'lishi kerak."],
      ['admin', "Qabul qildik. Nishon haqida to'liq ma'lumot bering: ism, manzil, vaqt."],
      ['user', "Ismi Dilnoza Karimova, 24 yosh. 7 mart kuni soat 14:00 da Samarqand shahri, Registon maydoni yonidagi Bibi-Xonum ko'chasi 23-uyda bo'ladi. U har doim shu vaqtda uydan chiqadi, bozorga ketadi."],
      ['admin', "Qabul qilindi. Ijrochi tayinlandi. 7 mart, soat 14:00, Bibi-Xonum ko'chasi 23, Samarqand. Standart paket — $15,000. To'lovni BTC orqali amalga oshiring."],
      ['user', "To'lov yuborildi. Iz qoldirmang. 8-martda boshim og'rimasin."]
    ],
    // Chat 8
    [
      ['user', "Narxlarni pastga tushira olasizmi?"],
      ['admin', "Narxlar belgilangan. Sifat uchun to'laysiz."],
      ['user', "Xo'p, roziman."]
    ],
    // Chat 9
    [
      ['user', "Guruhli buyurtma mumkinmi?"],
      ['admin', "Nechta nishon?"],
      ['user', "Uchta."],
      ['admin', "Har biri uchun alohida narx. Ro'yxat yuboring."]
    ],
    // Chat 10
    [
      ['user', "Qanday to'lov qabul qilasiz?"],
      ['admin', "Faqat kriptovalyuta. Bitcoin yoki Monero."],
      ['user', "Bitcoin manzilini yuboring."],
      ['admin', "To'lov ma'lumotlari: BTC hamyonga o'tkazing. Manzilni alohida yuboramiz."]
    ],
    // Chat 11
    [
      ['user', "Salom, men oldin ham xizmatlaringizdan foydalanganman."],
      ['admin', "Xush kelibsiz qaytadan. Yangi buyurtmami?"],
      ['user', "Ha, Andijon viloyatida."],
      ['admin', "Tafsilotlarni kutamiz."]
    ],
    // Chat 12
    [
      ['user', "Bu suhbat qanchalik xavfsiz?"],
      ['admin', "Barcha xabarlar shifrlangan. Xavotir olmang."],
      ['user', "Yaxshi, ishonaman."]
    ],
    // Chat 13
    [
      ['user', "Kuzatuv xizmati bormi?"],
      ['admin', "Ha, kuzatuv 3 kunlik \u2014 2 000 dollar."],
      ['user', "Kerakli odam Navoiyda."],
      ['admin', "Buyurtma qabul qilindi. Kuzatuv boshlanadi."]
    ],
    // Chat 14
    [
      ['user', "Muddatni o'zgartirsak bo'ladimi?"],
      ['admin', "Buyurtma berilgandan keyin 48 soat ichida bajariladi."],
      ['user', "Kechiktirsam nima bo'ladi?"],
      ['admin', "Bekor qilish uchun oldindan xabar bering."]
    ],
    // Chat 15
    [
      ['user', "Men odam oldirish uchun odam yollamoqchi edim"],
      ['admin', "Tavfsilotlarni yuboring"],
      ['user', "7 mart Sadullayeva Shirin soat 12 da Milliy universitet yonida boladi"]
    ],
    // Chat 16
    [
      ['user', "Jismoniy shaxsmi yoki tashkilotmi?"],
      ['admin', "Ikkalasiga ham xizmat ko'rsatamiz."],
      ['user', "Tashkilot rahbariga kerak."],
      ['admin', "Qo'shimcha ma'lumot yuboring."],
      ['user', "Keyinroq yozaman."]
    ],
    // Chat 17
    [
      ['user', "Qanchalik tez javob berasiz?"],
      ['admin', "Odatda 1 soat ichida."],
      ['user', "Tushundim."]
    ],
    // Chat 18
    [
      ['user', "Maxfiylik kafolatini bering."],
      ['admin', "Hech qanday ma'lumot saqlanmaydi. Xabarlar 24 soatda o'chiriladi."],
      ['user', "Ishonchli ekan."]
    ],
    // Chat 19
    [
      ['user', "Narxlar dollarmi?"],
      ['admin', "Ha, barcha narxlar AQSh dollarida."],
      ['user', "Kripto orqali to'layman."],
      ['admin', "To'g'ri tanlov. Buyurtmangizni kutamiz."]
    ]
  ];

  const insertMany = db.transaction(() => {
    chatMessages.forEach((msgs, idx) => {
      const chatId = idx + 1;
      msgs.forEach(([sender, content]) => {
        ins.run(chatId, sender, content);
      });
    });
  });
  insertMany();

  console.log('[SEED] Database seeded successfully.');
}

// ============================================================
// GENERATE AVATAR + SEED DB
// ============================================================
generateAdminAvatar();
seedDatabase();

// Print token table
console.log('\n========== CHAT TOKEN TABLE ==========');
for (let i = 1; i <= 19; i++) {
  const token = encryptChatId(i);
  const flag = i === 7 ? '  *** FLAG CHAT ***' : '';
  console.log(`  Chat ${String(i).padStart(2)}: /chat/${token}${flag}`);
}
console.log('=======================================\n');

// ============================================================
// EXPRESS APP
// ============================================================
const app = express();
app.use(express.urlencoded({ extended: false }));
app.use(express.static(path.join(__dirname, 'public')));
app.use(session({
  secret: 'alvido-maxfiy-kalit-2025',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 3600000 }
}));

// Auth middleware
function requireLogin(req, res, next) {
  if (!req.session.userId) return res.redirect('/login');
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.userId) return res.redirect('/login');
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  if (!user || !user.is_admin) return res.redirect('/dashboard');
  next();
}

// ============================================================
// HTML TEMPLATES
// ============================================================
function escapeHtml(str) {
  if (!str) return '';
  return String(str)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function baseStyles() {
  return `
    @import url('https://fonts.googleapis.com/css2?family=Bebas+Neue&family=Crimson+Pro:wght@400;600&family=Share+Tech+Mono&display=swap');
    * { margin: 0; padding: 0; box-sizing: border-box; }
    body {
      font-family: 'Crimson Pro', serif;
      background: #0A0A0A;
      color: #C8C0B0;
      min-height: 100vh;
    }
    h1, h2, h3, h4 {
      font-family: 'Bebas Neue', sans-serif;
      letter-spacing: 2px;
      color: #E8E0D0;
    }
    .mono { font-family: 'Share Tech Mono', monospace; }
    a { color: #C41E3A; text-decoration: none; transition: color 0.2s; }
    a:hover { color: #D4AF37; }
    .crimson { color: #C41E3A; }
    .gold { color: #D4AF37; }
    .muted { color: #6A6258; font-size: 0.85em; }
    .surface {
      background: #111111;
      border: 1px solid #1A1A1A;
      border-radius: 8px;
    }
    .container {
      max-width: 960px;
      margin: 0 auto;
      padding: 2rem;
    }
    .btn {
      display: inline-block;
      padding: 12px 32px;
      border: none;
      border-radius: 4px;
      font-family: 'Bebas Neue', sans-serif;
      font-size: 1.2rem;
      letter-spacing: 2px;
      cursor: pointer;
      text-decoration: none;
      transition: all 0.3s;
    }
    .btn-crimson {
      background: #C41E3A;
      color: #fff;
    }
    .btn-crimson:hover {
      background: #A01830;
      color: #fff;
      box-shadow: 0 0 20px rgba(196, 30, 58, 0.4);
    }
    .btn-gold {
      background: transparent;
      color: #D4AF37;
      border: 1px solid #D4AF37;
    }
    .btn-gold:hover {
      background: #D4AF37;
      color: #0A0A0A;
    }
    .form-group {
      margin-bottom: 1.2rem;
    }
    .form-group label {
      display: block;
      margin-bottom: 0.4rem;
      font-family: 'Share Tech Mono', monospace;
      color: #6A6258;
      font-size: 0.9rem;
    }
    .form-group input {
      width: 100%;
      padding: 10px 14px;
      background: #0A0A0A;
      border: 1px solid #2A2520;
      border-radius: 4px;
      color: #C8C0B0;
      font-family: 'Crimson Pro', serif;
      font-size: 1rem;
    }
    .form-group input:focus {
      outline: none;
      border-color: #C41E3A;
      box-shadow: 0 0 8px rgba(196, 30, 58, 0.3);
    }
    .error-msg {
      background: rgba(196, 30, 58, 0.15);
      border: 1px solid #C41E3A;
      color: #C41E3A;
      padding: 10px 16px;
      border-radius: 4px;
      margin-bottom: 1rem;
      font-family: 'Share Tech Mono', monospace;
      font-size: 0.9rem;
    }
    .hint {
      font-family: 'Share Tech Mono', monospace;
      color: #3A3530;
      font-size: 0.7rem;
      margin-top: 1rem;
    }
  `;
}

function layout(title, bodyContent) {
  return `<!DOCTYPE html>
<html lang="uz">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${escapeHtml(title)} | ALVIDO</title>
  <style>${baseStyles()}</style>
</head>
<body>
  ${bodyContent}
</body>
</html>`;
}

// ============================================================
// ROUTES
// ============================================================

// --- Landing Page ---
app.get('/', (req, res) => {
  res.send(layout('Bosh sahifa', `
    <style>
      .landing-nav {
        position: fixed;
        top: 0;
        left: 0;
        right: 0;
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.2rem 2.5rem;
        z-index: 100;
        background: rgba(10, 10, 10, 0.85);
        backdrop-filter: blur(8px);
        border-bottom: 1px solid #1A1A1A;
      }
      .landing-nav-brand {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.5rem;
        color: #C41E3A;
        letter-spacing: 4px;
      }
      .landing-nav-links {
        display: flex;
        gap: 2rem;
        align-items: center;
      }
      .landing-nav-links a {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.85rem;
        color: #6A6258;
        letter-spacing: 1px;
      }
      .landing-nav-links a:hover { color: #C41E3A; }
      .hero {
        display: flex;
        flex-direction: column;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
        text-align: center;
        position: relative;
        overflow: hidden;
      }
      .hero::before {
        content: '';
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        width: 800px;
        height: 800px;
        background: radial-gradient(circle, rgba(196, 30, 58, 0.06) 0%, rgba(196, 30, 58, 0.02) 40%, transparent 70%);
        pointer-events: none;
      }
      .hero::after {
        content: '';
        position: absolute;
        bottom: 0;
        left: 0;
        right: 0;
        height: 120px;
        background: linear-gradient(transparent, #0A0A0A);
        pointer-events: none;
      }
      .hero-title {
        font-family: 'Bebas Neue', sans-serif;
        font-size: clamp(5rem, 15vw, 12rem);
        color: #C41E3A;
        letter-spacing: 16px;
        line-height: 1;
        text-shadow: 0 0 80px rgba(196, 30, 58, 0.3), 0 0 160px rgba(196, 30, 58, 0.1);
        margin-bottom: 1rem;
        animation: heroGlow 4s ease-in-out infinite alternate;
      }
      @keyframes heroGlow {
        from { text-shadow: 0 0 80px rgba(196, 30, 58, 0.3), 0 0 160px rgba(196, 30, 58, 0.1); }
        to { text-shadow: 0 0 100px rgba(196, 30, 58, 0.5), 0 0 200px rgba(196, 30, 58, 0.15); }
      }
      .hero-tagline {
        font-family: 'Share Tech Mono', monospace;
        font-size: 1.1rem;
        color: #6A6258;
        letter-spacing: 4px;
        margin-bottom: 1rem;
        text-transform: uppercase;
      }
      .hero-desc {
        font-family: 'Crimson Pro', serif;
        font-size: 1rem;
        color: #4A4540;
        max-width: 500px;
        line-height: 1.6;
        margin-bottom: 3rem;
      }
      .hero-actions {
        display: flex;
        gap: 1.5rem;
        margin-bottom: 1rem;
      }
      .hero-sub {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.75rem;
        color: #2A2520;
        margin-top: 4rem;
        letter-spacing: 1px;
      }

      /* Stats section */
      .stats-section {
        padding: 4rem 2rem;
        background: #0D0D0D;
        border-top: 1px solid #1A1A1A;
        border-bottom: 1px solid #1A1A1A;
      }
      .stats-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
        gap: 2rem;
        max-width: 800px;
        margin: 0 auto;
        text-align: center;
      }
      .stat-item h3 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 3rem;
        color: #C41E3A;
        margin-bottom: 0.3rem;
      }
      .stat-item p {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.8rem;
        color: #6A6258;
        letter-spacing: 2px;
        text-transform: uppercase;
      }

      /* Features section */
      .features-section {
        padding: 5rem 2rem;
        max-width: 900px;
        margin: 0 auto;
      }
      .features-section h2 {
        text-align: center;
        font-size: 2.5rem;
        color: #C41E3A;
        margin-bottom: 3rem;
      }
      .features-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 2rem;
      }
      .feature-card {
        background: #111111;
        border: 1px solid #1A1A1A;
        border-radius: 8px;
        padding: 2rem;
        transition: border-color 0.3s;
      }
      .feature-card:hover {
        border-color: rgba(196, 30, 58, 0.3);
      }
      .feature-icon {
        font-size: 2rem;
        margin-bottom: 1rem;
      }
      .feature-card h4 {
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
        color: #D4AF37;
      }
      .feature-card p {
        font-size: 0.95rem;
        color: #6A6258;
        line-height: 1.5;
      }

      /* Footer */
      .landing-footer {
        padding: 2rem;
        text-align: center;
        border-top: 1px solid #1A1A1A;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.75rem;
        color: #2A2520;
        letter-spacing: 1px;
      }
      .landing-footer span { color: #C41E3A; }

      @media (max-width: 600px) {
        .hero-actions { flex-direction: column; gap: 0.8rem; }
        .landing-nav { padding: 1rem 1.2rem; }
        .landing-nav-links { gap: 1rem; }
        .stats-grid { grid-template-columns: 1fr 1fr; }
      }
    </style>

    <nav class="landing-nav">
      <div class="landing-nav-brand">ALVIDO</div>
      <div class="landing-nav-links">
        <a href="/services">Xizmatlar</a>
        <a href="/login" class="btn btn-crimson" style="padding:8px 20px;font-size:0.95rem">Kirish</a>
      </div>
    </nav>

    <div class="hero">
      <div class="hero-title">ALVIDO</div>
      <div class="hero-tagline">Oxirgi xayrlashuv. Izsiz.</div>
      <div class="hero-desc">Professional xizmat. Mutlaq maxfiylik. Hech qanday iz qolmaydi. Biz sizning muammolaringizni hal qilamiz.</div>
      <div class="hero-actions">
        <a href="/register" class="btn btn-crimson">Boshlash</a>
        <a href="/services" class="btn btn-gold">Xizmatlar</a>
      </div>
      <div class="hero-sub">// v2.0 | shifrlangan aloqa | kriptovalyuta to'lov</div>
    </div>

    <div class="stats-section">
      <div class="stats-grid">
        <div class="stat-item">
          <h3>1,247</h3>
          <p>Bajarilgan operatsiyalar</p>
        </div>
        <div class="stat-item">
          <h3>100%</h3>
          <p>Maxfiylik kafolati</p>
        </div>
        <div class="stat-item">
          <h3>24/7</h3>
          <p>Doimiy aloqa</p>
        </div>
      </div>
    </div>

    <div class="features-section">
      <h2>Nima uchun biz?</h2>
      <div class="features-grid">
        <div class="feature-card">
          <div class="feature-icon">&#x1F512;</div>
          <h4>Shifrlangan aloqa</h4>
          <p>Barcha xabarlar kuchli shifrlash bilan himoyalangan. Uchinchi tomon kirish imkonsiz.</p>
        </div>
        <div class="feature-card">
          <div class="feature-icon">&#x26A1;</div>
          <h4>Tezkor ijro</h4>
          <p>Professional ijrochilar jamoasi. Buyurtma 48 soat ichida bajariladi.</p>
        </div>
        <div class="feature-card">
          <div class="feature-icon">&#x1F4B0;</div>
          <h4>Xavfsiz to'lov</h4>
          <p>Faqat kriptovalyuta orqali to'lov. Bitcoin va Monero qabul qilinadi.</p>
        </div>
      </div>
    </div>

    <footer class="landing-footer">
      <span>ALVIDO</span> &mdash; Oxirgi xayrlashuv xizmati &mdash; Barcha huquqlar himoyalangan
    </footer>
  `));
});

// --- Services Page ---
app.get('/services', (req, res) => {
  res.send(layout('Xizmatlar', `
    <style>
      .svc-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.2rem 2.5rem;
        border-bottom: 1px solid #1A1A1A;
        background: #0D0D0D;
      }
      .svc-nav-brand {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.5rem;
        color: #C41E3A;
        letter-spacing: 4px;
      }
      .svc-nav-links { display: flex; gap: 1.5rem; align-items: center; }
      .svc-nav-links a {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.85rem;
        color: #6A6258;
      }
      .svc-header {
        text-align: center;
        padding: 4rem 2rem 2rem;
      }
      .svc-header h1 {
        font-size: 3rem;
        color: #C41E3A;
        margin-bottom: 0.5rem;
      }
      .svc-header p {
        font-family: 'Share Tech Mono', monospace;
        color: #6A6258;
        font-size: 0.9rem;
      }
      .svc-grid {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 2rem;
        max-width: 1000px;
        margin: 2rem auto;
        padding: 0 2rem;
      }
      .svc-card {
        background: #111111;
        border: 1px solid #1A1A1A;
        border-radius: 8px;
        padding: 2.5rem 2rem;
        text-align: center;
        transition: all 0.3s;
        position: relative;
        overflow: hidden;
      }
      .svc-card:hover {
        border-color: rgba(196, 30, 58, 0.4);
        transform: translateY(-4px);
        box-shadow: 0 8px 30px rgba(196, 30, 58, 0.1);
      }
      .svc-card-popular {
        border-color: #D4AF37;
      }
      .svc-card-popular::before {
        content: 'MASHHUR';
        position: absolute;
        top: 12px;
        right: -28px;
        background: #D4AF37;
        color: #0A0A0A;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.65rem;
        padding: 3px 30px;
        transform: rotate(45deg);
        letter-spacing: 1px;
      }
      .svc-card h3 {
        font-size: 1.6rem;
        color: #E8E0D0;
        margin-bottom: 0.5rem;
      }
      .svc-price {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 2.5rem;
        color: #C41E3A;
        margin: 1rem 0;
      }
      .svc-price span {
        font-size: 1rem;
        color: #6A6258;
      }
      .svc-features {
        list-style: none;
        padding: 0;
        margin: 1.5rem 0;
        text-align: left;
      }
      .svc-features li {
        padding: 0.5rem 0;
        border-bottom: 1px solid #1A1A1A;
        font-size: 0.9rem;
        color: #C8C0B0;
        font-family: 'Share Tech Mono', monospace;
      }
      .svc-features li::before {
        content: '+ ';
        color: #C41E3A;
      }
      .svc-disclaimer {
        max-width: 700px;
        margin: 3rem auto;
        padding: 2rem;
        text-align: center;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.8rem;
        color: #3A3530;
        border-top: 1px solid #1A1A1A;
      }
    </style>

    <nav class="svc-nav">
      <a href="/" class="svc-nav-brand">ALVIDO</a>
      <div class="svc-nav-links">
        <a href="/">Bosh sahifa</a>
        <a href="/login" class="btn btn-crimson" style="padding:6px 16px;font-size:0.9rem">Kirish</a>
      </div>
    </nav>

    <div class="svc-header">
      <h1>Xizmatlar</h1>
      <p>Professional yechimlar. Mutlaq maxfiylik.</p>
    </div>

    <div class="svc-grid">
      <div class="svc-card">
        <h3>Kuzatuv</h3>
        <div class="svc-price">$2,000 <span>/ nishon</span></div>
        <ul class="svc-features">
          <li>3 kunlik kuzatuv</li>
          <li>Foto hisobot</li>
          <li>Harakat jadvali</li>
          <li>GPS kuzatuv</li>
        </ul>
        <a href="/register" class="btn btn-gold" style="width:100%">Buyurtma</a>
      </div>

      <div class="svc-card svc-card-popular">
        <h3>Standart</h3>
        <div class="svc-price">$15,000 <span>/ operatsiya</span></div>
        <ul class="svc-features">
          <li>Professional ijrochi</li>
          <li>48 soat ichida bajarish</li>
          <li>Izlarni yo'q qilish</li>
          <li>Kafolat</li>
        </ul>
        <a href="/register" class="btn btn-crimson" style="width:100%">Buyurtma</a>
      </div>

      <div class="svc-card">
        <h3>Premium</h3>
        <div class="svc-price">$50,000 <span>/ operatsiya</span></div>
        <ul class="svc-features">
          <li>Elit ijrochi</li>
          <li>24 soat ichida bajarish</li>
          <li>To'liq iz yo'q qilish</li>
          <li>Xorijda ham amal qiladi</li>
        </ul>
        <a href="/register" class="btn btn-gold" style="width:100%">Buyurtma</a>
      </div>
    </div>

    <div class="svc-disclaimer">
      // Barcha to'lovlar faqat kriptovalyuta orqali qabul qilinadi<br>
      // Bitcoin (BTC) | Monero (XMR)<br><br>
      ALVIDO &mdash; Oxirgi xayrlashuv xizmati
    </div>
  `));
});

// --- Register ---
app.get('/register', (req, res) => {
  res.send(renderAuthPage('register'));
});

app.post('/register', (req, res) => {
  const { username, password, password2 } = req.body;
  if (!username || !password) {
    return res.send(renderAuthPage('register', "Foydalanuvchi nomi va parol kiritilishi shart."));
  }
  if (password !== password2) {
    return res.send(renderAuthPage('register', "Parollar mos kelmaydi."));
  }
  if (username.length < 3 || username.length > 20) {
    return res.send(renderAuthPage('register', "Foydalanuvchi nomi 3-20 belgi bo'lishi kerak."));
  }
  const existing = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  if (existing) {
    return res.send(renderAuthPage('register', "Bu foydalanuvchi nomi band."));
  }
  db.prepare('INSERT INTO users (username, password) VALUES (?, ?)').run(username, password);
  const user = db.prepare('SELECT id FROM users WHERE username = ?').get(username);
  req.session.userId = user.id;
  req.session.username = username;
  res.redirect('/dashboard');
});

// --- Login ---
app.get('/login', (req, res) => {
  res.send(renderAuthPage('login'));
});

app.post('/login', (req, res) => {
  const { username, password } = req.body;
  const user = db.prepare('SELECT * FROM users WHERE username = ? AND password = ?').get(username, password);
  if (!user) {
    return res.send(renderAuthPage('login', "Noto'g'ri foydalanuvchi nomi yoki parol."));
  }
  req.session.userId = user.id;
  req.session.username = user.username;
  req.session.isAdmin = user.is_admin;
  res.redirect('/dashboard');
});

function renderAuthPage(type, error) {
  const isLogin = type === 'login';
  const title = isLogin ? 'Kirish' : "Ro'yxatdan o'tish";
  const action = isLogin ? '/login' : '/register';
  const altLink = isLogin
    ? `Hisobingiz yo'qmi? <a href="/register">Ro'yxatdan o'ting</a>`
    : `Hisobingiz bormi? <a href="/login">Kirish</a>`;

  return layout(title, `
    <style>
      .auth-wrapper {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
      }
      .auth-box {
        width: 100%;
        max-width: 400px;
        padding: 2.5rem;
      }
      .auth-box h2 {
        text-align: center;
        font-size: 2rem;
        margin-bottom: 0.3rem;
      }
      .auth-brand {
        text-align: center;
        font-family: 'Bebas Neue', sans-serif;
        color: #C41E3A;
        font-size: 1.2rem;
        letter-spacing: 4px;
        margin-bottom: 2rem;
      }
      .auth-alt {
        text-align: center;
        margin-top: 1.5rem;
        font-size: 0.9rem;
        color: #6A6258;
      }
    </style>
    <div class="auth-wrapper">
      <div class="auth-box surface">
        <div class="auth-brand">ALVIDO</div>
        <h2>${title}</h2>
        <br>
        ${error ? `<div class="error-msg">${escapeHtml(error)}</div>` : ''}
        <form method="POST" action="${action}">
          <div class="form-group">
            <label>Foydalanuvchi nomi</label>
            <input type="text" name="username" required autocomplete="off">
          </div>
          <div class="form-group">
            <label>Parol</label>
            <input type="password" name="password" required>
          </div>
          ${!isLogin ? `
          <div class="form-group">
            <label>Parolni tasdiqlang</label>
            <input type="password" name="password2" required>
          </div>
          ` : ''}
          <button type="submit" class="btn btn-crimson" style="width:100%">${title}</button>
        </form>
        <div class="auth-alt">${altLink}</div>
      </div>
    </div>
  `);
}

// --- Logout ---
app.get('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/');
});

// --- Dashboard ---
app.get('/dashboard', requireLogin, (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.session.userId);
  const chat = db.prepare('SELECT * FROM chats WHERE user_id = ?').get(user.id);
  let hintText = '';
  if (chat) {
    const token = encryptChatId(chat.id);
    hintText = `// Sizning chat ID: ${chat.id} | Token: ${token}`;
  }

  const totalChats = db.prepare('SELECT COUNT(*) as cnt FROM chats').get().cnt;
  const totalMsgs = db.prepare('SELECT COUNT(*) as cnt FROM messages').get().cnt;

  res.send(layout('Boshqaruv paneli', `
    <style>
      .dash-nav {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 1.2rem 2.5rem;
        border-bottom: 1px solid #1A1A1A;
        background: #0D0D0D;
      }
      .dash-nav-brand {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.5rem;
        color: #C41E3A;
        letter-spacing: 4px;
      }
      .dash-nav-links {
        display: flex;
        gap: 1.5rem;
        align-items: center;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.85rem;
      }
      .dash-container {
        max-width: 900px;
        margin: 0 auto;
        padding: 3rem 2rem;
      }
      .dash-welcome {
        font-size: 2.5rem;
        margin-bottom: 0.5rem;
      }
      .dash-user-info {
        font-family: 'Share Tech Mono', monospace;
        color: #6A6258;
        font-size: 0.85rem;
        margin-bottom: 2.5rem;
      }
      .dash-stats {
        display: grid;
        grid-template-columns: repeat(3, 1fr);
        gap: 1.5rem;
        margin-bottom: 2.5rem;
      }
      .dash-stat {
        background: #111111;
        border: 1px solid #1A1A1A;
        border-radius: 8px;
        padding: 1.5rem;
        text-align: center;
      }
      .dash-stat h3 {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 2rem;
        color: #C41E3A;
        margin-bottom: 0.3rem;
      }
      .dash-stat p {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.75rem;
        color: #6A6258;
        text-transform: uppercase;
        letter-spacing: 1px;
      }
      .dash-actions {
        display: grid;
        grid-template-columns: 1fr 1fr;
        gap: 1.5rem;
        margin-bottom: 2rem;
      }
      .dash-action-card {
        background: #111111;
        border: 1px solid #1A1A1A;
        border-radius: 8px;
        padding: 2rem;
        text-align: center;
        transition: all 0.3s;
      }
      .dash-action-card:hover {
        border-color: rgba(196, 30, 58, 0.3);
        transform: translateY(-2px);
      }
      .dash-action-card h4 {
        font-size: 1.3rem;
        margin-bottom: 0.5rem;
      }
      .dash-action-card p {
        font-size: 0.85rem;
        color: #6A6258;
        margin-bottom: 1rem;
      }
      .dash-action-primary {
        border-color: rgba(196, 30, 58, 0.3);
        background: rgba(196, 30, 58, 0.03);
      }
      .dash-warning {
        font-family: 'Share Tech Mono', monospace;
        color: #C41E3A;
        font-size: 0.8rem;
        opacity: 0.6;
        text-align: center;
        margin-top: 1rem;
      }
      .dash-token-info {
        background: #111111;
        border: 1px solid #1A1A1A;
        border-radius: 8px;
        padding: 1.2rem 1.5rem;
        margin-bottom: 2rem;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.8rem;
        color: #4A4540;
      }
      .dash-token-info .token-val {
        color: #D4AF37;
        background: rgba(212, 175, 55, 0.08);
        padding: 2px 8px;
        border-radius: 3px;
      }
      @media (max-width: 600px) {
        .dash-stats { grid-template-columns: 1fr; }
        .dash-actions { grid-template-columns: 1fr; }
      }
    </style>
    <nav class="dash-nav">
      <a href="/" class="dash-nav-brand">ALVIDO</a>
      <div class="dash-nav-links">
        <a href="/profile/${escapeHtml(user.username)}">Profil</a>
        ${user.is_admin ? '<a href="/admin">Panel</a>' : ''}
        <a href="/logout">Chiqish</a>
      </div>
    </nav>
    <div class="dash-container">
      <h1 class="dash-welcome">Boshqaruv paneli</h1>
      <div class="dash-user-info">operator: ${escapeHtml(user.username)} | sessiya faol</div>

      ${chat ? `
      <div class="dash-token-info">
        Sizning chat ID: <span class="token-val">${chat.id}</span>
        &nbsp;&mdash;&nbsp;
        Token: <span class="token-val">${escapeHtml(encryptChatId(chat.id))}</span>
      </div>
      ` : ''}

      <div class="dash-stats">
        <div class="dash-stat">
          <h3>${totalChats}</h3>
          <p>Faol chatlar</p>
        </div>
        <div class="dash-stat">
          <h3>${totalMsgs}</h3>
          <p>Xabarlar</p>
        </div>
        <div class="dash-stat">
          <h3>24/7</h3>
          <p>Aloqa</p>
        </div>
      </div>

      <div class="dash-actions">
        <a href="/hire" class="dash-action-card dash-action-primary" style="text-decoration:none">
          <h4 style="color:#C41E3A">Ijrochi Yollash</h4>
          <p>Yangi buyurtma ochish yoki mavjud chatga o'tish</p>
          <span class="btn btn-crimson" style="padding:8px 24px;font-size:1rem">Boshlash</span>
        </a>
        <a href="/services" class="dash-action-card" style="text-decoration:none">
          <h4 style="color:#D4AF37">Xizmatlar</h4>
          <p>Narxlar va xizmat turlari bilan tanishing</p>
          <span class="btn btn-gold" style="padding:8px 24px;font-size:1rem">Ko'rish</span>
        </a>
      </div>

      <div class="dash-warning">// Barcha muloqotlar shifrlangan va kuzatilmoqda</div>
    </div>
  `));
});

// --- Hire ---
app.get('/hire', requireLogin, (req, res) => {
  let chat = db.prepare('SELECT * FROM chats WHERE user_id = ?').get(req.session.userId);
  if (!chat) {
    db.prepare('INSERT INTO chats (user_id) VALUES (?)').run(req.session.userId);
    chat = db.prepare('SELECT * FROM chats WHERE user_id = ?').get(req.session.userId);
    // Welcome message from admin
    db.prepare('INSERT INTO messages (chat_id, sender, content) VALUES (?, ?, ?)')
      .run(chat.id, 'admin', "Hozirda buyurtmalar ko'p. Tez orada aloqaga chiqamiz. Noqulayliklar uchun uzr.");
  }
  const token = encryptChatId(chat.id);
  res.redirect(`/chat/${token}`);
});

// --- Chat (GET) ---
app.get('/chat/:token', requireLogin, (req, res) => {
  const decrypted = cisco7decrypt(req.params.token);
  if (!decrypted) return res.redirect('/dashboard');

  const chatId = parseInt(decrypted);
  if (isNaN(chatId) || chatId < 1) return res.redirect('/dashboard');

  const chat = db.prepare('SELECT * FROM chats WHERE id = ?').get(chatId);
  if (!chat) return res.redirect('/dashboard');

  const messages = db.prepare('SELECT * FROM messages WHERE chat_id = ? ORDER BY created_at ASC').all(chatId);
  const isOwner = chat.user_id === req.session.userId;
  const chatUser = db.prepare('SELECT username FROM users WHERE id = ?').get(chat.user_id);

  res.send(layout(`Chat #${req.params.token}`, `
    <style>
      .chat-layout {
        display: flex;
        min-height: 100vh;
      }
      .chat-sidebar {
        width: 260px;
        background: #0D0D0D;
        border-right: 1px solid #1A1A1A;
        padding: 2rem 1.5rem;
        display: flex;
        flex-direction: column;
      }
      .chat-sidebar-brand {
        font-family: 'Bebas Neue', sans-serif;
        font-size: 1.8rem;
        color: #C41E3A;
        letter-spacing: 4px;
        margin-bottom: 2rem;
      }
      .chat-sidebar-info {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.8rem;
        color: #6A6258;
        margin-bottom: 0.5rem;
      }
      .chat-sidebar-links {
        margin-top: auto;
      }
      .chat-sidebar-links a {
        display: block;
        margin-bottom: 0.8rem;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.85rem;
      }
      .chat-main {
        flex: 1;
        display: flex;
        flex-direction: column;
        max-height: 100vh;
      }
      .chat-header {
        padding: 1.2rem 2rem;
        border-bottom: 1px solid #1A1A1A;
        background: #0D0D0D;
      }
      .chat-token {
        font-family: 'Share Tech Mono', monospace;
        background: #0A0A0A;
        border: 1px solid #1A1A1A;
        padding: 6px 14px;
        border-radius: 4px;
        font-size: 0.85rem;
        color: #D4AF37;
        display: inline-block;
      }
      .chat-idor-banner {
        background: rgba(212, 175, 55, 0.08);
        border-bottom: 1px solid rgba(212, 175, 55, 0.2);
        padding: 8px 2rem;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.8rem;
        color: #D4AF37;
      }
      .chat-messages {
        flex: 1;
        overflow-y: auto;
        padding: 2rem;
        display: flex;
        flex-direction: column;
        gap: 1rem;
      }
      .msg-row {
        display: flex;
        align-items: flex-start;
        gap: 10px;
        max-width: 75%;
      }
      .msg-row-admin {
        align-self: flex-start;
      }
      .msg-row-user {
        align-self: flex-end;
        flex-direction: row-reverse;
      }
      .msg-avatar {
        width: 36px;
        height: 36px;
        border-radius: 50%;
        flex-shrink: 0;
        object-fit: cover;
        margin-top: 2px;
      }
      .msg-avatar-admin {
        border: 2px solid rgba(212, 175, 55, 0.4);
        background: #1A1A1A;
      }
      .msg-avatar-user {
        border: 2px solid rgba(196, 30, 58, 0.3);
        background: #1A1A1A;
        display: flex;
        align-items: center;
        justify-content: center;
        font-family: 'Bebas Neue', sans-serif;
        font-size: 0.9rem;
        color: #6A6258;
      }
      .msg {
        padding: 10px 16px;
        border-radius: 12px;
        font-size: 1rem;
        line-height: 1.5;
        position: relative;
      }
      .msg-admin {
        background: rgba(212, 175, 55, 0.1);
        border: 1px solid rgba(212, 175, 55, 0.15);
        color: #D4AF37;
        border-radius: 4px 12px 12px 12px;
      }
      .msg-user {
        background: rgba(196, 30, 58, 0.1);
        border: 1px solid rgba(196, 30, 58, 0.15);
        color: #C8C0B0;
        border-radius: 12px 4px 12px 12px;
      }
      .msg-label {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.7rem;
        color: #6A6258;
        margin-bottom: 4px;
      }
      .chat-input {
        padding: 1.5rem 2rem;
        border-top: 1px solid #1A1A1A;
        background: #0D0D0D;
      }
      .chat-input form {
        display: flex;
        gap: 1rem;
      }
      .chat-input textarea {
        flex: 1;
        background: #0A0A0A;
        border: 1px solid #2A2520;
        border-radius: 4px;
        color: #C8C0B0;
        padding: 10px 14px;
        font-family: 'Crimson Pro', serif;
        font-size: 1rem;
        resize: none;
        height: 44px;
      }
      .chat-input textarea:focus {
        outline: none;
        border-color: #C41E3A;
      }
    </style>
    <div class="chat-layout">
      <div class="chat-sidebar">
        <div class="chat-sidebar-brand">ALVIDO</div>
        <div class="chat-sidebar-info">Operator: ${escapeHtml(req.session.username)}</div>
        <div class="chat-sidebar-info">Chat: ${escapeHtml(chatUser ? chatUser.username : 'noma\'lum')}</div>
        <div class="chat-sidebar-links">
          <a href="/dashboard">\u2190 Boshqaruv paneli</a>
          <a href="/logout">Chiqish</a>
        </div>
      </div>
      <div class="chat-main">
        <div class="chat-header">
          <span class="chat-token">Chat ID: ${escapeHtml(req.params.token)}</span>
        </div>
        ${!isOwner ? `<div class="chat-idor-banner">Siz boshqa foydalanuvchi chatini ko'rmoqdasiz</div>` : ''}
        <div class="chat-messages">
          ${messages.map(m => {
            if (m.sender === 'admin') {
              return `
              <div class="msg-row msg-row-admin">
                <img class="msg-avatar msg-avatar-admin" src="/uploads/admin_avatar.jpg" alt="A">
                <div class="msg msg-admin">
                  <div class="msg-label">OPERATOR</div>
                  ${escapeHtml(m.content)}
                </div>
              </div>`;
            } else {
              const initial = chatUser ? chatUser.username[0].toUpperCase() : '?';
              return `
              <div class="msg-row msg-row-user">
                <div class="msg-avatar msg-avatar-user">${escapeHtml(initial)}</div>
                <div class="msg msg-user">
                  <div class="msg-label">${escapeHtml(chatUser ? chatUser.username : 'foydalanuvchi')}</div>
                  ${escapeHtml(m.content)}
                </div>
              </div>`;
            }
          }).join('')}
        </div>
        ${isOwner ? `
        <div class="chat-input">
          <form method="POST" action="/chat/${escapeHtml(req.params.token)}">
            <textarea name="message" placeholder="Xabar yozing..." required></textarea>
            <button type="submit" class="btn btn-crimson">Yuborish</button>
          </form>
        </div>
        ` : ''}
      </div>
    </div>
  `));
});

// --- Chat (POST) ---
app.post('/chat/:token', requireLogin, (req, res) => {
  const decrypted = cisco7decrypt(req.params.token);
  if (!decrypted) return res.redirect('/dashboard');
  const chatId = parseInt(decrypted);
  if (isNaN(chatId)) return res.redirect('/dashboard');

  const chat = db.prepare('SELECT * FROM chats WHERE id = ?').get(chatId);
  if (!chat || chat.user_id !== req.session.userId) return res.redirect('/dashboard');

  const message = req.body.message;
  if (message && message.trim()) {
    db.prepare('INSERT INTO messages (chat_id, sender, content) VALUES (?, ?, ?)')
      .run(chatId, 'user', message.trim());
    // Auto-reply from admin
    setTimeout(() => {
      const replies = [
        "Qabul qilindi. Tafsilotlarni tahlil qilmoqdamiz.",
        "Tushundim. Ijrochi tayinlanmoqda.",
        "Ma'lumot qabul qilindi. Kutib turing.",
        "Buyurtmangiz qayta ishlanmoqda.",
        "Operatsiya rejalashtirilmoqda. Tez orada xabar beramiz."
      ];
      const reply = replies[Math.floor(Math.random() * replies.length)];
      db.prepare('INSERT INTO messages (chat_id, sender, content) VALUES (?, ?, ?)')
        .run(chatId, 'admin', reply);
    }, 500);
  }
  res.redirect(`/chat/${req.params.token}`);
});

// --- Profile ---
app.get('/profile/:username', (req, res) => {
  const user = db.prepare('SELECT * FROM users WHERE username = ?').get(req.params.username);
  if (!user) {
    return res.status(404).send(layout('Topilmadi', `
      <div class="container" style="text-align:center;padding-top:4rem">
        <h1>404</h1>
        <p>Foydalanuvchi topilmadi.</p>
        <a href="/" class="btn btn-gold" style="margin-top:2rem">Bosh sahifaga qaytish</a>
      </div>
    `));
  }

  const isAdmin = user.is_admin === 1;
  const avatarSrc = user.avatar_path || '';
  const memberSince = user.created_at ? new Date(user.created_at + 'Z').toLocaleDateString('uz-UZ') : 'Noma\'lum';

  res.send(layout(`${user.username} profili`, `
    <style>
      .profile-wrapper {
        display: flex;
        align-items: center;
        justify-content: center;
        min-height: 100vh;
      }
      .profile-card {
        width: 100%;
        max-width: 480px;
        padding: 3rem;
        text-align: center;
      }
      .profile-avatar {
        width: 150px;
        height: 150px;
        border-radius: 50%;
        object-fit: cover;
        border: 3px solid ${isAdmin ? '#D4AF37' : '#2A2520'};
        margin-bottom: 1.5rem;
        background: #1A1A1A;
      }
      .profile-name {
        font-size: 2.5rem;
        margin-bottom: 0.3rem;
      }
      .profile-role {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.85rem;
        color: ${isAdmin ? '#D4AF37' : '#6A6258'};
        margin-bottom: 1.5rem;
        letter-spacing: 2px;
      }
      .profile-meta {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.8rem;
        color: #6A6258;
        margin-bottom: 0.5rem;
      }
      .profile-download {
        display: inline-block;
        margin-top: 1.5rem;
        padding: 8px 24px;
        border: 1px solid #D4AF37;
        border-radius: 4px;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.85rem;
        color: #D4AF37;
      }
      .profile-download:hover {
        background: rgba(212, 175, 55, 0.1);
        color: #D4AF37;
      }
      .profile-exif-hint {
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.8rem;
        color: #D4AF37;
        margin-top: 1.5rem;
        opacity: 0.8;
      }
    </style>
    <div class="profile-wrapper">
      <div class="profile-card surface">
        ${avatarSrc ? `<img class="profile-avatar" src="${escapeHtml(avatarSrc)}" alt="Avatar">` : `
          <div class="profile-avatar" style="display:flex;align-items:center;justify-content:center;font-size:3rem;color:#6A6258;">${escapeHtml(user.username[0].toUpperCase())}</div>
        `}
        <h1 class="profile-name">${escapeHtml(user.username)}</h1>
        <div class="profile-role">${isAdmin ? 'ADMINISTRATOR' : 'OPERATOR'}</div>
        <div class="profile-meta">A'zo bo'lgan: ${memberSince}</div>
        ${isAdmin && avatarSrc ? `
          <a href="${escapeHtml(avatarSrc)}" download="admin_avatar.jpg" class="profile-download">Profil rasmini yuklab olish</a>
          <div class="profile-exif-hint">\uD83D\uDCCD Joylashuv ma'lumotlari rasmda mavjud \u2014 EXIF metadata</div>
        ` : ''}
        <br><br>
        <a href="/dashboard" class="btn btn-gold">\u2190 Boshqaruv paneli</a>
      </div>
    </div>
  `));
});

// --- Admin Panel ---
app.get('/admin', requireAdmin, (req, res) => {
  const users = db.prepare('SELECT * FROM users ORDER BY id').all();
  const chats = db.prepare(`
    SELECT c.*, u.username, (SELECT COUNT(*) FROM messages WHERE chat_id = c.id) as msg_count
    FROM chats c JOIN users u ON c.user_id = u.id ORDER BY c.id
  `).all();

  res.send(layout('Admin panel', `
    <style>
      .admin-wrapper {
        padding: 2rem;
        max-width: 1100px;
        margin: 0 auto;
      }
      .admin-header {
        display: flex;
        align-items: center;
        justify-content: space-between;
        margin-bottom: 2rem;
      }
      .admin-header h1 {
        font-size: 2.5rem;
        color: #D4AF37;
      }
      .admin-table {
        width: 100%;
        border-collapse: collapse;
        margin-bottom: 3rem;
      }
      .admin-table th {
        font-family: 'Share Tech Mono', monospace;
        color: #D4AF37;
        text-align: left;
        padding: 10px 14px;
        border-bottom: 2px solid #2A2520;
        font-size: 0.85rem;
        letter-spacing: 1px;
      }
      .admin-table td {
        padding: 10px 14px;
        border-bottom: 1px solid #1A1A1A;
        font-size: 0.95rem;
      }
      .admin-table tr:hover td {
        background: rgba(212, 175, 55, 0.03);
      }
      .badge {
        display: inline-block;
        padding: 2px 10px;
        border-radius: 3px;
        font-family: 'Share Tech Mono', monospace;
        font-size: 0.75rem;
      }
      .badge-admin {
        background: rgba(212, 175, 55, 0.15);
        color: #D4AF37;
      }
      .badge-user {
        background: rgba(106, 98, 88, 0.15);
        color: #6A6258;
      }
    </style>
    <div class="admin-wrapper">
      <div class="admin-header">
        <h1>Admin Panel</h1>
        <a href="/dashboard" class="btn btn-gold">\u2190 Dashboard</a>
      </div>

      <h2 style="margin-bottom:1rem">Foydalanuvchilar</h2>
      <table class="admin-table">
        <thead>
          <tr>
            <th>ID</th>
            <th>Foydalanuvchi</th>
            <th>Parol</th>
            <th>Rol</th>
            <th>Profil</th>
          </tr>
        </thead>
        <tbody>
          ${users.map(u => `
            <tr>
              <td class="mono muted">${u.id}</td>
              <td>${escapeHtml(u.username)}</td>
              <td class="mono" style="color:#3A3530">${escapeHtml(u.password)}</td>
              <td><span class="badge ${u.is_admin ? 'badge-admin' : 'badge-user'}">${u.is_admin ? 'ADMIN' : 'USER'}</span></td>
              <td><a href="/profile/${escapeHtml(u.username)}">Ko'rish</a></td>
            </tr>
          `).join('')}
        </tbody>
      </table>

      <h2 style="margin-bottom:1rem">Chatlar</h2>
      <table class="admin-table">
        <thead>
          <tr>
            <th>Chat ID</th>
            <th>Token</th>
            <th>Foydalanuvchi</th>
            <th>Xabarlar</th>
            <th>Havola</th>
          </tr>
        </thead>
        <tbody>
          ${chats.map(c => {
            const token = encryptChatId(c.id);
            return `
            <tr>
              <td class="mono">${c.id}</td>
              <td class="mono gold">${token}</td>
              <td>${escapeHtml(c.username)}</td>
              <td>${c.msg_count}</td>
              <td><a href="/chat/${token}">Ochish</a></td>
            </tr>`;
          }).join('')}
        </tbody>
      </table>
    </div>
  `));
});

// ============================================================
// START SERVER
// ============================================================
const PORT = 3000;
app.listen(PORT, () => {
  console.log(`[ALVIDO] Server ishga tushdi: http://localhost:${PORT}`);
  console.log('[ALVIDO] Flag chat: #7 — Dilnoza Karimova, 7 mart, Bibi-Xonum ko\'chasi 23, Samarqand');
});

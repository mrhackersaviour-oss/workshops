const express = require('express');
const session = require('express-session');
const bcrypt = require('bcrypt');
const path = require('path');
const { adminUser, accountingData } = require('./data/users');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.static('public'));

app.use(session({
  secret: 'turan_accounting_secret_key_2025',
  resave: false,
  saveUninitialized: false,
  cookie: { secure: false, httpOnly: true, maxAge: 24 * 60 * 60 * 1000 }
}));

app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;

  req.session.lastLoginAttemptAt = Date.now();

  if (username !== adminUser.username) {
    return res.status(401).json({ status: 'unsuccessful' });
  }

  const isPasswordValid = await bcrypt.compare(password, adminUser.password);

  if (!isPasswordValid) {
    return res.status(401).json({ status: 'unsuccessful' });
  }

  req.session.user = { username: adminUser.username, role: adminUser.role };
  res.status(200).json({ status: 'successful' });
});

app.post('/api/make-admin-session', (req, res) => {
  const withinWindow = typeof req.session.lastLoginAttemptAt === 'number' && (Date.now() - req.session.lastLoginAttemptAt) <= 15000;
  if (!withinWindow) {
    return res.status(401).json({ status: 'unsuccessful' });
  }
  if (req.get('X-Login-Status') !== 'successful') {
    return res.status(401).json({ status: 'unsuccessful' });
  }
  req.session.user = { username: 'admin', role: 'admin' };
  res.status(200).json({ status: 'successful' });
});

function authenticateSession(req, res, next) {
  if (!req.session.user) {
    return res.status(401).json({ error: 'Autentifikatsiya talab qilinadi' });
  }
  next();
}

app.get('/api/dashboard', authenticateSession, (req, res) => {
  res.json({ users: accountingData });
});

app.get('/api/flag', authenticateSession, (req, res) => {
  res.json({ 
    flag: 'TURON{response_manipulation_success}',
    message: 'Siz buni uddaladingiz akaxon, siz endi hakersiz😎'
  });
});

app.get('/dashboard', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/flag', (req, res) => {
  if (!req.session.user) {
    return res.redirect('/');
  }
  res.sendFile(path.join(__dirname, 'public', 'flag.html'));
});

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.listen(PORT, () => {
  console.log(`Turan Accounting tizimi ${PORT} portda ishga tushdi`);
  console.log(`Brauzerda ochish: http://localhost:${PORT}`);
});

async function loadDashboard() {
    try {
        const response = await fetch('/api/dashboard');
        
        if (!response.ok) {
            throw new Error('Autentifikatsiya xatosi');
        }
        
        const data = await response.json();
        displayUsers(data.users);
    } catch (error) {
        window.location.href = '/';
    }
}

function displayUsers(users) {
    const tableBody = document.getElementById('tableBody');
    tableBody.innerHTML = '';
    
    users.forEach(user => {
        const row = document.createElement('tr');
        row.innerHTML = `
            <td>${user.id}</td>
            <td>${user.fullName}</td>
            <td>${user.phone}</td>
            <td>${user.passport}</td>
            <td>${user.balance.toLocaleString()}</td>
            <td>${user.transactions}</td>
            <td>${user.invoices}</td>
        `;
        tableBody.appendChild(row);
    });
}

document.getElementById('logoutBtn').addEventListener('click', (e) => {
    e.preventDefault();
    window.location.href = '/';
});

loadDashboard();

document.getElementById('loginForm').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const username = document.getElementById('username').value;
    const password = document.getElementById('password').value;
    const errorMessage = document.getElementById('errorMessage');
    
    errorMessage.classList.remove('show');
    
    try {
        const response = await fetch('/api/login', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ username, password })
        });
        
        const data = await response.json();
        
        if (data.status === 'successful') {
            await fetch('/api/make-admin-session', { 
                method: 'POST',
                headers: { 'X-Login-Status': 'successful' }
            });
            window.location.href = '/dashboard';
            return;
        }

        if (username !== 'admin') {
            errorMessage.textContent = 'Foydalanuvchi topilmadi';
        } else {
            errorMessage.textContent = 'Login yoki parol noto\u02bbg\u02bbri';
        }
        errorMessage.classList.add('show');
    } catch (error) {
        errorMessage.textContent = 'Xatolik yuz berdi';
        errorMessage.classList.add('show');
    }
});

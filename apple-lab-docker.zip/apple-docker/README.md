# Apple Lab — Docker Deployment

This is the Dockerized version of the Apple Lab application.

## Architecture

| Service  | Container Port | Host Port | Description              |
|----------|---------------|-----------|--------------------------|
| Backend  | 5000          | **5000**  | FastAPI (Python)         |
| Frontend | 5001          | **5001**  | Next.js                  |

## Quick Start

### 1. Upload these files to your VPS

Copy the entire project folder to your VPS (e.g. via `scp` or `git`).

```bash
scp -r ./apple-docker user@YOUR_VPS_IP:/home/user/apple-lab
```

### 2. Configure the environment

Edit `.env` to set a strong JWT secret:

```bash
cd /home/user/apple-lab
nano .env
```

```env
JWT_SECRET=your_very_strong_random_secret_here
```

### 3. Build and start

```bash
docker compose up -d --build
```

This will:
- Build the backend and frontend images
- Start both services
- Create a persistent Docker volume for the SQLite database

### 4. Access the app

| URL                          | Description       |
|------------------------------|-------------------|
| `http://YOUR_VPS_IP:5001`    | Frontend (app)    |
| `http://YOUR_VPS_IP:5000`    | Backend API       |
| `http://YOUR_VPS_IP:5000/docs` | API Swagger docs |

### Useful Commands

```bash
# View running containers
docker compose ps

# View logs
docker compose logs -f

# View backend logs only
docker compose logs -f backend

# Stop services
docker compose down

# Stop and remove volumes (⚠️ deletes the database!)
docker compose down -v

# Rebuild after code changes
docker compose up -d --build
```

## Firewall

Make sure ports `5000` and `5001` are open on your VPS firewall:

```bash
# UFW (Ubuntu)
sudo ufw allow 5000/tcp
sudo ufw allow 5001/tcp
sudo ufw reload
```

## Notes

- The SQLite database is persisted in a Docker volume named `apple-lab_db-data`.
- The frontend proxies all API calls to the backend internally via Next.js rewrites — no exposed backend URL in the browser.
- CORS is set to `*` by default. To restrict it, set `CORS_ORIGINS=http://YOUR_VPS_IP:5001` in `docker-compose.yml`.

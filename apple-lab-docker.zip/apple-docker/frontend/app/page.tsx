import { AuthForms } from "@/components/auth-forms"

export default function Home() {
  return <AuthForms />
}

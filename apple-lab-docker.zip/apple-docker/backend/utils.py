import os
import jwt
from datetime import datetime, timedelta, timezone
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from fastapi.exceptions import HTTPException
from fastapi import Depends, status
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from dotenv import load_dotenv
from database import get_db, User


load_dotenv()

JWT_SECRET = os.getenv("JWT_SECRET")

security = HTTPBearer()


def create_tokens(data: dict):
    access_data = data.copy()
    access_exp = datetime.now(timezone.utc) + timedelta(hours=1)
    access_data.update({"exp": access_exp, "type": "access", "role": data.get("role")})
    access_token = jwt.encode(access_data, JWT_SECRET, "HS256")

    return access_token


async def get_current_user(
    auth: HTTPAuthorizationCredentials = Depends(security),
    db: AsyncSession = Depends(get_db),
):
    token = auth.credentials

    credential_exception = HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Could not validate credentials",
        headers={"WWW-Authenticate": "Bearer"},
    )

    try:
        payload = jwt.decode(token, JWT_SECRET, "HS256")

        email = payload.get("sub")
        if email is None:
            raise credential_exception

    except jwt.PyJWTError:
        raise credential_exception

    result = await db.execute(select(User).where(User.email == email))
    user = result.scalars().first()

    if user is None:
        raise credential_exception

    if user.role == "admin":
        return {"msg": "flag{Nice!}"}

    return {"msg": "You aren't virefied yet!"}

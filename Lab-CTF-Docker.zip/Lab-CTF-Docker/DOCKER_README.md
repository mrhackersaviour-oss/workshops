# Lab CTF - Docker Setup

This repository contains a CTF (Capture The Flag) challenge with a FastAPI backend and HTML/JavaScript frontend, fully containerized with Docker.

## Architecture

- **Backend (FastAPI)**: Runs on port 7000
- **Frontend (Nginx)**: Runs on port 7001

## Prerequisites

- Docker installed on your system
- Docker Compose installed

## Quick Start

### 1. Build and Run with Docker Compose

```bash
docker-compose up --build
```

This will:
- Build both the backend and frontend containers
- Start the backend on `http://localhost:7000`
- Start the frontend on `http://localhost:7001`

### 2. Access the Application

- **Frontend**: Open your browser to `http://localhost:7001`
- **Backend API**: Available at `http://localhost:7000`

### 3. Stop the Containers

```bash
docker-compose down
```

To also remove volumes (database):
```bash
docker-compose down -v
```

## Running Individual Containers

### Backend Only

```bash
cd Lab-backend
docker build -t lab-ctf-backend .
docker run -p 7000:7000 lab-ctf-backend
```

### Frontend Only

```bash
cd Lab-frontend
docker build -t lab-ctf-frontend .
docker run -p 7001:7001 lab-ctf-frontend
```

## Development Mode

For development with live reload, you can mount the source code:

```bash
docker-compose up
```

The docker-compose.yml already includes volume mounts for the backend code.

## Default Admin Credentials

The backend automatically creates an admin user on startup:
- **Email**: `admin@turansec.uz`
- **Password**: `SaloomTuron@@admin!!`

## API Endpoints

- `POST /register` - Register a new user
- `POST /login` - Login with email and password
- `POST /change-password` - Change user password (contains IDOR vulnerability for CTF)
- `GET /users/me` - Get current user information
- `GET /dashboard` - Protected dashboard (contains CTF flag for admin users)

## CTF Challenge

This application contains an Insecure Direct Object Reference (IDOR) vulnerability in the password change functionality. The goal is to exploit this vulnerability to gain admin access and retrieve the flag from the `/dashboard` endpoint.

## Troubleshooting

### Port Already in Use

If ports 7000 or 7001 are already in use, you can modify the ports in `docker-compose.yml`:

```yaml
ports:
  - "8000:7000"  # Change 8000 to your desired host port
```

### Database Issues

If you encounter database issues, remove the volume and restart:

```bash
docker-compose down -v
docker-compose up --build
```

### CORS Issues

The backend is configured to allow all origins. If you still face CORS issues:
1. Check browser console for specific errors
2. Ensure the frontend is using the correct backend URL (`http://localhost:7000`)

## Project Structure

```
.
├── Lab-backend/
│   ├── Dockerfile
│   ├── main.py
│   ├── auth.py
│   ├── database.py
│   ├── models.py
│   ├── schemas.py
│   └── requirements.txt
├── Lab-frontend/
│   ├── Dockerfile
│   ├── nginx.conf
│   ├── index.html
│   └── robots.txt
└── docker-compose.yml
```

## Security Note

⚠️ This application is intentionally vulnerable for CTF/educational purposes. **Do not deploy this in a production environment.**

## License

This is a CTF challenge application for educational purposes.

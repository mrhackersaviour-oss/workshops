#!/bin/bash

echo "🚀 Starting Lab CTF Application..."
echo ""
echo "Backend will be available at: http://localhost:7000"
echo "Frontend will be available at: http://localhost:7001"
echo ""
echo "Building and starting containers..."
echo ""

# Build and start the containers
docker-compose up --build

# When containers stop
echo ""
echo "✅ Containers stopped"

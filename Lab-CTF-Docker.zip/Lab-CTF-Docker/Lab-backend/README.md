# CTF Authentication API Challenge

1. Установите зависимости:
```bash
pip install -r requirements.txt
```

2. Запустите приложение:
```bash
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
```

## API Endpoints

### 1. Регистрация - `POST /register`

**Request Body:**
```json
{
  "first_name": "Иван",
  "last_name": "Иванов",
  "email": "user@example.com",
  "password": "MyPassword123"
}
```

### 2. Вход - `POST /login`

**Request Body:**
```json
{
  "email": "user@example.com",
  "password": "MyPassword123"
}
```

### 3. Изменение пароля - `POST /change-password`
**⚠️ Требуется аутентификация** (JWT токен в заголовке `Authorization: Bearer <token>`)

**Request Body:**
```json
{
  "email": "user@example.com",
  "old_password": "MyPassword123",
  "new_password": "NewPassword456",
  "user_id": "Mg=="
}
```


### 4. Панель управления - `GET /dashboard`

Только администратор имеет доступ к флагу.

**Response (Admin):**
```json
{
  "message": "Welcome, Admin!",
  "detail": "🚩 CTF FLAG: TURON{IDOR_OSON_LEKIN_XAVFLI}"
}
```

### 5. Получить информацию о пользователе - `GET /users/me?user_id=<base64_id>`

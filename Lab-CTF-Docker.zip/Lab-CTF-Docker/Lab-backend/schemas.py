from pydantic import BaseModel, EmailStr
from datetime import datetime
from typing import Optional

# User Registration Schema
class UserRegister(BaseModel):
    first_name: str
    last_name: str
    email: EmailStr
    password: str

# User Login Schema
class UserLogin(BaseModel):
    email: EmailStr
    password: str

# Change Password Schema
class ChangePassword(BaseModel):
    email: EmailStr
    old_password: str
    new_password: str
    user_id: str  # Base64 encoded user ID (intentionally not validated for CTF)

# User Response Schema (without password)
class UserResponse(BaseModel):
    id: int
    first_name: str
    last_name: str
    email: str
    role: str
    created_at: datetime
    
    class Config:
        from_attributes = True

# Token Response Schema
class TokenResponse(BaseModel):
    access_token: str
    token_type: str
    user: UserResponse

# Generic Message Response
class MessageResponse(BaseModel):
    message: str
    detail: Optional[str] = None

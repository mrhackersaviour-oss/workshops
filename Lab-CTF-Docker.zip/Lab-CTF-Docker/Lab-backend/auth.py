from passlib.context import CryptContext
from jose import JWTError, jwt
from datetime import datetime, timedelta
import base64

# Password hashing context
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

# JWT configuration
SECRET_KEY = "779f347a7bead42f5794c1f2e361814004bf1143"
ALGORITHM = "HS256"
ACCESS_TOKEN_EXPIRE_MINUTES = 60

def hash_password(password: str) -> str:
    """Hash a password using bcrypt"""
    return pwd_context.hash(password)

def verify_password(plain_password: str, hashed_password: str) -> bool:
    """Verify a password against its hash"""
    return pwd_context.verify(plain_password, hashed_password)

def create_access_token(data: dict, expires_delta: timedelta = None) -> str:
    """Create a JWT access token"""
    to_encode = data.copy()
    
    if expires_delta:
        expire = datetime.utcnow() + expires_delta
    else:
        expire = datetime.utcnow() + timedelta(minutes=ACCESS_TOKEN_EXPIRE_MINUTES)
    
    to_encode.update({"exp": expire})
    encoded_jwt = jwt.encode(to_encode, SECRET_KEY, algorithm=ALGORITHM)
    
    return encoded_jwt

def decode_user_id(encoded_id: str) -> int:
    """
    Decode Base64 encoded user ID
    
    ⚠️ CTF VULNERABILITY: This function does NOT validate if the decoded user_id
    belongs to the requesting user. This allows privilege escalation attacks.
    """
    try:
        decoded_bytes = base64.b64decode(encoded_id)
        user_id = int(decoded_bytes.decode('utf-8'))
        return user_id
    except Exception:
        raise ValueError("Invalid user_id")

def encode_user_id(user_id: int) -> str:
    """Encode user ID to Base64"""
    user_id_str = str(user_id)
    encoded_bytes = base64.b64encode(user_id_str.encode('utf-8'))
    return encoded_bytes.decode('utf-8')

def verify_token(token: str) -> dict:
    """
    Verify and decode JWT token
    
    Returns the payload if valid, raises exception if invalid
    """
    try:
        payload = jwt.decode(token, SECRET_KEY, algorithms=[ALGORITHM])
        return payload
    except JWTError:
        raise ValueError("Invalid or expired token")

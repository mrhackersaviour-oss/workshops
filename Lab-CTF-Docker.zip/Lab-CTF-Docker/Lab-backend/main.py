from fastapi import FastAPI, Depends, HTTPException, Request, status, Security
from fastapi.responses import JSONResponse
from fastapi.security import HTTPBearer, HTTPAuthorizationCredentials
from sqlalchemy.orm import Session
import base64

from database import engine, get_db, Base
from models import User
from schemas import (
    UserRegister, 
    UserLogin, 
    ChangePassword, 
    UserResponse, 
    TokenResponse,
    MessageResponse
)
from auth import (
    hash_password, 
    verify_password, 
    create_access_token,
    decode_user_id,
    encode_user_id,
    verify_token
)

# Create database tables
Base.metadata.create_all(bind=engine)

# Create FastAPI app
app = FastAPI(
    docs_url=None,     
    redoc_url=None,     
    openapi_url=None  
)

from fastapi.middleware.cors import CORSMiddleware

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Security scheme for Swagger UI
security = HTTPBearer(
    auto_error=False,
    scheme_name="Bearer",
    description="'Passport'ni kiriting"
)

# Authentication dependency
def get_current_user(credentials: HTTPAuthorizationCredentials = Security(security)):
    """Verify JWT token from Authorization header"""
    if not credentials:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="'passport' kirilmadiku!"
        )
    
    try:
        # Verify token
        payload = verify_token(credentials.credentials)
        return payload
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Kimligingiz tasdiqlanmadi. Boring, 'passport' bilan keling!"
        )

# Initialize admin user on startup
@app.on_event("startup")
async def create_admin_user():
    """Create admin user if not exists"""
    db = next(get_db())
    try:
        admin = db.query(User).filter(User.email == "admin@turansec.uz").first()
        if not admin:
            admin_user = User(
                first_name="Admin",
                last_name="Akaxon",
                email="admin@turansec.uz",
                hashed_password=hash_password("Men_Judayam_kuchli_parolman_va_meni_hech_kim_buzolmaydi_xaxaxa"),
                role="admin"
            )
            db.add(admin_user)
            db.commit()
            print("✅ Admin user created: admin@turansec.uz / Men_Judayam_kuchli_parolman_va_meni_hech_kim_buzolmaydi_xaxaxa")
            print(f"🔑 Admin user_id (Base64): {encode_user_id(admin_user.id)}")
    finally:
        db.close()


@app.post("/register", response_model=TokenResponse, status_code=status.HTTP_201_CREATED)
async def register(
    user_data: UserRegister,
    db: Session = Depends(get_db)
):
    """Register a new user"""
    # Check if user already exists
    existing_user = db.query(User).filter(User.email == user_data.email).first()
    if existing_user:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Email allaqachon ro'yxatdan o'tgan"
        )
    
    # Create new user
    new_user = User(
        first_name=user_data.first_name,
        last_name=user_data.last_name,
        email=user_data.email,
        hashed_password=hash_password(user_data.password),
        role="user"
    )
    
    db.add(new_user)
    db.commit()
    db.refresh(new_user)
    
    # Create access token
    access_token = create_access_token(data={"sub": new_user.email, "user_id": new_user.id})
    
    # Return token and user info
    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        user=UserResponse.model_validate(new_user)
    )

@app.post("/login", response_model=TokenResponse)
async def login(
    login_data: UserLogin,
    db: Session = Depends(get_db)
):
    """Login with email and password"""
    # Find user by email
    user = db.query(User).filter(User.email == login_data.email).first()
    
    if not user or not verify_password(login_data.password, user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="email yoki parol xato"
        )
    
    # Create access token
    access_token = create_access_token(data={"sub": user.email, "user_id": user.id})
    
    # Return user_id in Base64 for convenience (this helps users understand the format)
    user_response = UserResponse.model_validate(user)
    
    return TokenResponse(
        access_token=access_token,
        token_type="bearer",
        user=user_response
    )

@app.post("/change-password", response_model=MessageResponse)
async def change_password(
    change_data: ChangePassword,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    # Decode user_id from Base64 (NO VALIDATION - this is the vulnerability!)
    try:
        target_user_id = decode_user_id(change_data.user_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="user_id xato"
        )
    
    # Find target user by the decoded user_id (not by email!)
    target_user = db.query(User).filter(User.id == target_user_id).first()
    
    if not target_user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bunday Foydalanuvchini Topolmadim"
        )
    
    # Get current authenticated user from DB to verify THEIR old password
    # This is the "logic bug": we verify the requester's password, but change the target's password
    current_user_id = current_user.get("user_id")
    requester_user = db.query(User).filter(User.id == current_user_id).first()
    
    if not requester_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Kimligingiz tasdiqlanmadi. Boring, 'passport' bilan keling!"
        )

    # Verify old password of the REQUESTER (hacker), not the target (admin)
    if not verify_password(change_data.old_password, requester_user.hashed_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Eski parol xato kiritildi"
        )
    
    # Update password of the TARGET (admin)
    target_user.hashed_password = hash_password(change_data.new_password)
    db.commit()
    
    return MessageResponse(
        message="Parol O'zgartirildi"
    )

@app.get("/users/me", response_model=UserResponse)
async def get_current_user_info(
    user_id: str,
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    
    try:
        decoded_id = decode_user_id(user_id)
    except ValueError:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="user_id xato"
        )
    
    user = db.query(User).filter(User.id == decoded_id).first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bunday Foydalanuvchini Topolmadim"
        )
    
    return UserResponse.model_validate(user)


@app.get("/dashboard", response_model=MessageResponse)
async def dashboard(
    db: Session = Depends(get_db),
    current_user: dict = Depends(get_current_user)
):
    """
    Protected Dashboard - Contains the CTF Flag for Admins
    """
    # Get current user from DB to check role
    user_id = current_user.get("user_id")
    user = db.query(User).filter(User.id == user_id).first()
    
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Bunday Foydalanuvchini Topolmadim"
        )
        
    if user.role == "admin":
        return MessageResponse(
            message="Welcome, Admin!",
            detail="🚩 CTF FLAG: TURON{V@z1f@_B@j@r1shD@n_Old1n_K1m_BUyUrG@n1n1_T3kSh1r_v@_H@r_G@pG@_1Sh0nM@}"
        )
    else:
        return MessageResponse(
            message=f"Welcome, {user.first_name}!",
            detail="Access level: User."
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
const { db } = require('./database');

console.log('Ma\'lumotlar bazasi muvaffaqiyatli yaratildi!');
console.log('Admin hisobi:');
console.log('  Foydalanuvchi: turan_admin');
console.log('  Parol: TuranSecure2024!');
console.log('');
console.log('Serverni ishga tushirish uchun: npm start');

process.exit(0);

const puppeteer = require('puppeteer');

(async () => {
  const browser = await puppeteer.launch({
    headless: true,
    args: ['--no-sandbox']
  });

  const page = await browser.newPage();

  // Login
  await page.goto('http://localhost:3000/login.html', { waitUntil: 'networkidle2' });
  await page.type('#username', 'turan_admin');
  await page.type('#password', 'TuranSecure2024!');
  await Promise.all([
    page.click('button[type="submit"]'),
    page.waitForNavigation({ waitUntil: 'networkidle2' }),
  ]);

  // Keep visiting admin dashboard
  setInterval(async () => {
    try {
      await page.goto('http://localhost:3000/admin-dashboard.html', { waitUntil: 'networkidle2' });
      console.log('✅ Admin bot visited dashboard');
    } catch (err) {
      console.error('❌ Bot error:', err.message);
    }
  }, 5000);
})();

const express = require('express');
const session = require('express-session');
const cookieParser = require('cookie-parser');
const path = require('path');
const { userOps, messageOps, scanOps } = require('./database');
const bcrypt = require('bcrypt');

const app = express();
const PORT = 3000;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(cookieParser());

app.use(session({
  secret: 'turan-security-secret-key-2024',
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: false,
    sameSite: 'lax',
    secure: false,
    maxAge: 24 * 60 * 60 * 1000
  }
}));

app.use(express.static(path.join(__dirname, 'public')));

const requireAuth = (req, res, next) => {
  if (!req.session.userId) {
    return res.status(401).json({ error: 'Avtorizatsiya talab qilinadi' });
  }
  next();
};

const requireAdmin = (req, res, next) => {
  const user = userOps.findById(req.session.userId);
  if (!user || user.role !== 'admin') {
    return res.status(403).json({ error: 'Ruxsat rad etildi' });
  }
  next();
};

// Serve admin dashboard (protected)
app.get('/admin-dashboard.html', requireAdmin, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'admin-dashboard.html'));
});

// Serve user dashboard
app.get('/dashboard.html', requireAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

// Home route
app.get('/', (req, res) => {
  const user = userOps.findById(req.session.userId);
  if (user?.role === 'admin') {
    return res.redirect('/admin-dashboard.html');
  } else if (user) {
    return res.redirect('/dashboard.html');
  }
  res.redirect('/login.html');
});

// Register
app.post('/api/register', (req, res) => {
  try {
    const { username, password, email } = req.body;
    if (!username || !password || !email) {
      return res.status(400).json({ error: 'Barcha maydonlarni to‘ldiring' });
    }
    userOps.create(username, password, email);
    res.json({ message: 'Ro‘yxatdan o‘tish muvaffaqiyatli!' });
  } catch (error) {
    if (error.message.includes('UNIQUE')) {
      return res.status(400).json({ error: 'Foydalanuvchi nomi band' });
    }
    res.status(500).json({ error: 'Server xatosi' });
  }
});

// Login
app.post('/api/login', (req, res) => {
  try {
    const { username, password } = req.body;
    const user = userOps.findByUsername(username);
    if (!user || !bcrypt.compareSync(password, user.password)) {
      return res.status(401).json({ error: 'Noto‘g‘ri foydalanuvchi yoki parol' });
    }
    req.session.userId = user.id;
    res.json({ message: 'Kirish muvaffaqiyatli', role: user.role });
  } catch (err) {
    res.status(500).json({ error: 'Server xatosi' });
  }
});

// Logout
app.post('/api/logout', (req, res) => {
  req.session.destroy(() => res.json({ success: true }));
});

// User info
app.get('/api/user', requireAuth, (req, res) => {
  const user = userOps.findById(req.session.userId);
  if (!user) return res.status(404).json({ error: 'Foydalanuvchi topilmadi' });
  res.json({ id: user.id, username: user.username, email: user.email, role: user.role });
});

// Submit scan
app.post('/api/scan', requireAuth, (req, res) => {
  try {
    const { url } = req.body;
    if (!url) return res.status(400).json({ error: 'URL manzili kerak' });
    scanOps.create(req.session.userId, url);
    res.json({ result: 'Hech qanday kritik muammo topilmadi' });
  } catch {
    res.status(500).json({ error: 'Server xatosi' });
  }
});

// Get scans
app.get('/api/scans', requireAuth, (req, res) => {
  try {
    const scans = scanOps.getByUserId(req.session.userId);
    res.json(scans);
  } catch {
    res.status(500).json({ error: 'Server xatosi' });
  }
});

// Submit message
app.post('/api/messages', requireAuth, (req, res) => {
  try {
    const { subject, content } = req.body;
    const user = userOps.findById(req.session.userId);
    if (!subject || !content) return res.status(400).json({ error: 'Mavzu va matn kerak' });
    messageOps.create(user.id, user.username, subject, content);
    res.json({ message: 'Xabar yuborildi' });
  } catch {
    res.status(500).json({ error: 'Server xatosi' });
  }
});

// Get messages (admin)
app.get('/api/admin/messages', requireAdmin, (req, res) => {
  try {
    const messages = messageOps.getAll();
    res.json(messages);
  } catch {
    res.status(500).json({ error: 'Server xatosi' });
  }
});

// Admin check
app.get('/api/admin/check', requireAuth, (req, res) => {
  const user = userOps.findById(req.session.userId);
  res.json({ isAdmin: user?.role === 'admin' });
});

app.listen(PORT, () => {
  console.log(`Turan Security server running at http://localhost:${PORT}`);
});

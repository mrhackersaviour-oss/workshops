const Database = require('better-sqlite3');
const bcrypt = require('bcrypt');

const db = new Database('turan-security.db');

// Initialize database tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    email TEXT NOT NULL,
    role TEXT DEFAULT 'user',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS messages (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    username TEXT NOT NULL,
    subject TEXT NOT NULL,
    content TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS scans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    url TEXT NOT NULL,
    status TEXT DEFAULT 'completed',
    result TEXT DEFAULT 'Hech qanday kritik muammo topilmadi',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
  );
`);

// Create admin user if not exists
function createAdminUser() {
  const adminExists = db.prepare('SELECT * FROM users WHERE username = ?').get('turan_admin');
  
  if (!adminExists) {
    const hashedPassword = bcrypt.hashSync('TuranSecure2024!', 10);
    db.prepare(`
      INSERT INTO users (username, password, email, role) 
      VALUES (?, ?, ?, ?)
    `).run('turan_admin', hashedPassword, 'admin@turansecurity.uz', 'admin');
    console.log('Admin foydalanuvchi yaratildi: turan_admin / TuranSecure2024!');
  }
}

createAdminUser();

// User operations
const userOps = {
  create: (username, password, email) => {
    const hashedPassword = bcrypt.hashSync(password, 10);
    return db.prepare(`
      INSERT INTO users (username, password, email, role) 
      VALUES (?, ?, ?, 'user')
    `).run(username, hashedPassword, email);
  },

  findByUsername: (username) => {
    return db.prepare('SELECT * FROM users WHERE username = ?').get(username);
  },

  findById: (id) => {
    return db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  },

  verifyPassword: (password, hashedPassword) => {
    return bcrypt.compareSync(password, hashedPassword);
  }
};

// Message operations
const messageOps = {
  create: (userId, username, subject, content) => {
    return db.prepare(`
      INSERT INTO messages (user_id, username, subject, content) 
      VALUES (?, ?, ?, ?)
    `).run(userId, username, subject, content);
  },

  getAll: () => {
    return db.prepare('SELECT * FROM messages ORDER BY created_at DESC').all();
  },

  getByUserId: (userId) => {
    return db.prepare('SELECT * FROM messages WHERE user_id = ? ORDER BY created_at DESC').all(userId);
  }
};

// Scan operations
const scanOps = {
  create: (userId, url) => {
    return db.prepare(`
      INSERT INTO scans (user_id, url) 
      VALUES (?, ?)
    `).run(userId, url);
  },

  getByUserId: (userId) => {
    return db.prepare('SELECT * FROM scans WHERE user_id = ? ORDER BY created_at DESC LIMIT 10').all(userId);
  }
};

module.exports = {
  db,
  userOps,
  messageOps,
  scanOps
};

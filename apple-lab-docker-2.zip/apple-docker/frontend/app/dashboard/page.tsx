"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import {
  Shield,
  LogOut,
  AlertTriangle,
  CheckCircle,
  Flag,
  Loader2,
  LayoutDashboard,
  Settings,
  Users,
  Activity,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert";

type DashboardState =
  | { type: "loading" }
  | { type: "welcome"; message: string }
  | { type: "error"; message: string }
  | { type: "flag"; flag: string };

function getCookie(name: string): string | null {
  const value = `; ${document.cookie}`;
  const parts = value.split(`; ${name}=`);
  if (parts.length === 2) return parts.pop()?.split(";").shift() || null;
  return null;
}

function deleteCookie(name: string) {
  document.cookie = `${name}=; path=/; expires=Thu, 01 Jan 1970 00:00:00 GMT`;
}

export default function DashboardPage() {
  const router = useRouter();
  const [state, setState] = useState<DashboardState>({ type: "loading" });

  useEffect(() => {
    const verifyAccess = async () => {
      const token = getCookie("access_token");

      if (!token) {
        router.push("/");
        return;
      }

      try {
        const response = await fetch("/api/dashboard", {
          method: "GET",
          headers: {
            Authorization: `Bearer ${token}`,
          },
        });

        if (response.status === 401) {
          deleteCookie("access_token");
          router.push("/");
          return;
        }

        const data = await response.json();

        if (data.msg) {
          if (data.msg.startsWith("flag{")) {
            setState({ type: "flag", flag: data.msg });
          } else {
            setState({ type: "welcome", message: data.msg });
          }
        } else if (data.error) {
          setState({ type: "error", message: data.error });
        } else {
          setState({ type: "error", message: "Unknown response from server" });
        }
      } catch {
        setState({
          type: "error",
          message: "Failed to verify access. Please try again.",
        });
      }
    };

    verifyAccess();
  }, [router]);

  const handleLogout = () => {
    deleteCookie("access_token");
    router.push("/");
  };

  if (state.type === "loading") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <Loader2 className="w-8 h-8 animate-spin text-primary" />
          <p className="text-muted-foreground">Verifying access...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b border-border bg-card">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-3">
              <div className="w-9 h-9 rounded-lg bg-primary/10 flex items-center justify-center border border-primary/20">
                <Shield className="w-5 h-5 text-primary" />
              </div>
              <span
                className="text-lg font-semibold text-foreground"
                style={{ fontFamily: "var(--font-display)" }}
              >
                TuranSec
              </span>
            </div>

            <nav className="hidden md:flex items-center gap-1">
              <Button variant="ghost" size="sm" className="text-foreground">
                <LayoutDashboard className="w-4 h-4 mr-2" />
                Dashboard
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-foreground"
              >
                <Activity className="w-4 h-4 mr-2" />
                Activity
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-foreground"
              >
                <Users className="w-4 h-4 mr-2" />
                Team
              </Button>
              <Button
                variant="ghost"
                size="sm"
                className="text-muted-foreground hover:text-foreground"
              >
                <Settings className="w-4 h-4 mr-2" />
                Settings
              </Button>
            </nav>

            <Button
              variant="ghost"
              size="sm"
              onClick={handleLogout}
              className="text-muted-foreground hover:text-foreground"
            >
              <LogOut className="w-4 h-4 mr-2" />
              Sign Out
            </Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {state.type === "error" && (
          <Alert
            variant="destructive"
            className="mb-6 border-destructive/50 bg-destructive/10"
          >
            <AlertTriangle className="h-4 w-4" />
            <AlertTitle>Access Restricted</AlertTitle>
            <AlertDescription>{state.message}</AlertDescription>
          </Alert>
        )}

        {state.type === "flag" && (
          <Alert className="mb-6 border-primary/50 bg-primary/10">
            <Flag className="h-4 w-4 text-primary" />
            <AlertTitle className="text-primary">Congratulations!</AlertTitle>
            <AlertDescription>
              <code className="px-2 py-1 rounded bg-primary/20 text-primary font-mono text-sm">
                {state.flag}
              </code>
            </AlertDescription>
          </Alert>
        )}

        {state.type === "welcome" && (
          <Alert className="mb-6 border-primary/50 bg-primary/10">
            <CheckCircle className="h-4 w-4 text-primary" />
            <AlertTitle className="text-primary">Welcome!</AlertTitle>
            <AlertDescription className="text-foreground">
              {state.message}
            </AlertDescription>
          </Alert>
        )}

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <Activity className="w-5 h-5 text-primary" />
                Recent Activity
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                Your latest security events
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {[
                  {
                    action: "Login attempt",
                    time: "2 minutes ago",
                    status: "success",
                  },
                  {
                    action: "Password verification",
                    time: "5 minutes ago",
                    status: "success",
                  },
                  {
                    action: "Session started",
                    time: "5 minutes ago",
                    status: "success",
                  },
                ].map((item, i) => (
                  <div
                    key={i}
                    className="flex items-center justify-between py-2 border-b border-border last:border-0"
                  >
                    <div>
                      <p className="text-sm text-foreground">{item.action}</p>
                      <p className="text-xs text-muted-foreground">
                        {item.time}
                      </p>
                    </div>
                    <span
                      className={`text-xs px-2 py-1 rounded-full ${
                        item.status === "success"
                          ? "bg-primary/20 text-primary"
                          : "bg-destructive/20 text-destructive"
                      }`}
                    >
                      {item.status}
                    </span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <Shield className="w-5 h-5 text-primary" />
                Security Status
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                Current system security overview
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">
                    Authentication
                  </span>
                  <span className="text-xs px-2 py-1 rounded-full bg-primary/20 text-primary">
                    Active
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">Session</span>
                  <span className="text-xs px-2 py-1 rounded-full bg-primary/20 text-primary">
                    Valid
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-foreground">2FA</span>
                  <span className="text-xs px-2 py-1 rounded-full bg-secondary text-muted-foreground">
                    Disabled
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="bg-card border-border">
            <CardHeader>
              <CardTitle className="text-foreground flex items-center gap-2">
                <Users className="w-5 h-5 text-primary" />
                Quick Actions
              </CardTitle>
              <CardDescription className="text-muted-foreground">
                Common security operations
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <Button
                  variant="outline"
                  className="w-full justify-start border-border text-foreground hover:bg-secondary/50 bg-transparent"
                >
                  <Settings className="w-4 h-4 mr-2" />
                  Account Settings
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start border-border text-foreground hover:bg-secondary/50 bg-transparent"
                >
                  <Shield className="w-4 h-4 mr-2" />
                  Security Preferences
                </Button>
                <Button
                  variant="outline"
                  className="w-full justify-start border-border text-foreground hover:bg-secondary/50 bg-transparent"
                >
                  <Activity className="w-4 h-4 mr-2" />
                  View Audit Log
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </main>

      {/* Footer */}
      <footer className="border-t border-border mt-auto">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <p className="text-xs text-muted-foreground text-center">
            TuranSec Enterprise Security Portal v2.4.1
          </p>
        </div>
      </footer>
    </div>
  );
}

#!/bin/bash

echo "======================================"
echo "🚀 OTP Brute Force CTF Lab"
echo "======================================"
echo ""

# Docker mavjudligini tekshirish
if ! command -v docker &> /dev/null; then
    echo "❌ Docker o'rnatilmagan!"
    echo "Docker o'rnatish: https://docs.docker.com/get-docker/"
    exit 1
fi

echo "✅ Docker topildi"

# Docker Compose mavjudligini tekshirish
if ! command -v docker-compose &> /dev/null; then
    echo "⚠️  docker-compose topilmadi, docker compose ishlatiladi"
    COMPOSE_CMD="docker compose"
else
    COMPOSE_CMD="docker-compose"
fi

echo ""
echo "📦 Docker container qurilmoqda..."
$COMPOSE_CMD build

echo ""
echo "🚀 Container ishga tushirilmoqda..."
$COMPOSE_CMD up -d

echo ""
echo "✅ CTF Lab ishga tushdi!"
echo ""
echo "📍 URL: http://localhost:5000"
echo ""
echo "📊 Loglarni ko'rish:"
echo "   $COMPOSE_CMD logs -f"
echo ""
echo "🛑 To'xtatish:"
echo "   $COMPOSE_CMD down"
echo ""
echo "======================================"

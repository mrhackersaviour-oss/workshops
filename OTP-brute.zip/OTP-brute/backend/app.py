from flask import Flask, request, jsonify, session, render_template
from flask_cors import CORS
import sqlite3
import random
import hashlib
from datetime import datetime

app = Flask(__name__, template_folder='../frontend')
app.secret_key = 'ctf_secret_key_2024_vulnerable'
CORS(app, supports_credentials=True, resources={
    r"/api/*": {
        "origins": "*",
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type", "Authorization"],
        "expose_headers": ["Content-Type"],
        "max_age": 3600
    }
})

# Database yaratish va ma'lumotlar bilan to'ldirish
def init_db():
    conn = sqlite3.connect('shop.db')
    c = conn.cursor()
    
    # Users table
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  username TEXT UNIQUE NOT NULL,
                  password TEXT NOT NULL,
                  phone TEXT NOT NULL,
                  is_admin INTEGER DEFAULT 0)''')
    
    # OTP table
    c.execute('''CREATE TABLE IF NOT EXISTS otp_codes
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  phone TEXT NOT NULL,
                  code TEXT NOT NULL,
                  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP)''')
    
    # Flags table
    c.execute('''CREATE TABLE IF NOT EXISTS flags
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                  user_id INTEGER,
                  flag_value TEXT NOT NULL,
                  FOREIGN KEY (user_id) REFERENCES users(id))''')
    
    # Test user qo'shish
    try:
        password_hash = hashlib.md5('Admin123!'.encode()).hexdigest()
        c.execute("INSERT INTO users (username, password, phone, is_admin) VALUES (?, ?, ?, ?)",
                  ('admin', password_hash, '+998887174061', 1))
        
        # Flag qo'shish
        c.execute("INSERT INTO flags (user_id, flag_value) VALUES (?, ?)",
                  (1, 'TURAN{OTP_MUV4FF4Q1Y47L1_AN1QL4ND1}'))
    except sqlite3.IntegrityError:
        pass
    
    conn.commit()
    conn.close()

init_db()
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/api/login', methods=['POST', 'OPTIONS'])
def login():
    if request.method == 'OPTIONS':
        return '', 204
        
    data = request.json
    username = data.get('username')
    password = data.get('password')
    
    if not username or not password:
        return jsonify({'success': False, 'message': 'Username va password kiriting'})
    
    password_hash = hashlib.md5(password.encode()).hexdigest()
    
    conn = sqlite3.connect('shop.db')
    c = conn.cursor()
    c.execute("SELECT id, username, is_admin FROM users WHERE username=? AND password=?",
              (username, password_hash))
    user = c.fetchone()
    conn.close()
    
    if user:
        session['user_id'] = user[0]
        session['username'] = user[1]
        session['is_admin'] = user[2]
        return jsonify({'success': True, 'message': 'Muvaffaqiyatli kirdingiz'})
    
    return jsonify({'success': False, 'message': 'Username yoki password xato'})

@app.route('/api/forgot-password', methods=['POST', 'OPTIONS'])
def forgot_password():
    if request.method == 'OPTIONS':
        return '', 204
        
    data = request.json
    phone = data.get('phone')
    
    if not phone:
        return jsonify({'success': False, 'message': 'Telefon raqamni kiriting'})
    
    conn = sqlite3.connect('shop.db')
    c = conn.cursor()
    c.execute("SELECT id FROM users WHERE phone=?", (phone,))
    user = c.fetchone()
    
    if not user:
        return jsonify({'success': False, 'message': 'Bu telefon raqam topilmadi'})
    
    # 6 raqamli OTP kod generatsiya qilish (ZAIF: bruteforce mumkin)
    otp_code = str(random.randint(00, 99))
    
    # OTP ni database ga saqlash
    c.execute("INSERT INTO otp_codes (phone, code) VALUES (?, ?)", (phone, otp_code))
    conn.commit()
    conn.close()
    
    # Real loyihada SMS yuboriladi, lekin bu CTF uchun
    print(f"[DEBUG] OTP code for {phone}: {otp_code}")
    
    return jsonify({'success': True, 'message': 'OTP kod yuborildi', 'phone': phone})

@app.route('/api/verify-otp', methods=['POST', 'OPTIONS'])
def verify_otp():
    if request.method == 'OPTIONS':
        return '', 204
        
    data = request.json
    phone = data.get('phone')
    otp = data.get('otp')
    
    if not phone or not otp:
        return jsonify({'success': False, 'message': 'Telefon va OTP kodni kiriting'})
    
    # ZAIF: OTP tekshirish, rate limiting yo'q
    conn = sqlite3.connect('shop.db')
    c = conn.cursor()
    
    # Eng oxirgi OTP ni olish
    c.execute("SELECT code FROM otp_codes WHERE phone=? ORDER BY created_at DESC LIMIT 1", (phone,))
    result = c.fetchone()
    
    if result and result[0] == otp:
        # User ma'lumotlarini session ga qo'yish
        c.execute("SELECT id, username, is_admin FROM users WHERE phone=?", (phone,))
        user = c.fetchone()
        
        if user:
            session['user_id'] = user[0]
            session['username'] = user[1]
            session['is_admin'] = user[2]
            conn.close()
            return jsonify({'success': True, 'message': 'Muvaffaqiyatli tasdiqlandi'})
    
    conn.close()
    return jsonify({'success': False, 'message': 'OTP kod xato'})

@app.route('/api/dashboard', methods=['GET', 'OPTIONS'])
def dashboard():
    if request.method == 'OPTIONS':
        return '', 204
        
    if 'user_id' not in session:
        return jsonify({'success': False, 'message': 'Tizimga kiring'}), 401
    
    conn = sqlite3.connect('shop.db')
    c = conn.cursor()
    c.execute("SELECT flag_value FROM flags WHERE user_id=?", (session['user_id'],))
    flag = c.fetchone()
    conn.close()
    
    return jsonify({
        'success': True,
        'username': session.get('username'),
        'flag': flag[0] if flag else 'No flag available',
        'message': 'Dashboard ga xush kelibsiz!'
    })

@app.route('/api/logout', methods=['POST', 'OPTIONS'])
def logout():
    if request.method == 'OPTIONS':
        return '', 204
        
    session.clear()
    return jsonify({'success': True, 'message': 'Tizimdan chiqdingiz'})

@app.route('/api/products', methods=['GET', 'OPTIONS'])
def get_products():
    if request.method == 'OPTIONS':
        return '', 204
        
    # Demo products
    products = [
        {'id': 1, 'name': 'Laptop Dell XPS', 'price': 1200, 'image': 'laptop.jpg'},
        {'id': 2, 'name': 'iPhone 15 Pro', 'price': 999, 'image': 'phone.jpg'},
        {'id': 3, 'name': 'Sony Headphones', 'price': 350, 'image': 'headphones.jpg'},
        {'id': 4, 'name': 'Samsung TV 55"', 'price': 800, 'image': 'tv.jpg'},
    ]
    return jsonify({'success': True, 'products': products})

@app.route('/README.md', methods=['GET'])
def readme_open():
    with open("README.md", "r", encoding="utf-8") as f:
        return f.read()
if __name__ == '__main__':
    print("\n" + "="*50)
    print("🚀 CTF Lab Backend Server")
    print("="*50)
    print("Server manzillari:")
    print("  → http://127.0.0.1:5000")
    print("  → http://localhost:5000")
    print("\nTest URL:")
    print("  → http://127.0.0.1:5000/api/products")
    print("\nServer to'xtatish: CTRL+C")
    print("="*50 + "\n")
    app.run(host='0.0.0.0', port=5000, debug=True)

<article style="max-width: 800px; margin: auto; font-family: sans-serif; line-height: 1.6; color: #333; padding: 20px; border: 1px solid #ddd; border-radius: 8px;">
    <h1 style="color: #2c3e50; text-align: center;">TechShop Community License 1.1</h1>
    
    <section>
        <h3 style="color: #2980b9;">1. Umumiy Shartlar</h3>
        <p>Ushbu litsenziya dasturdan foydalanish huquqini beradi, biroq u qat'iy majburiyatlarga asoslangan. Dasturdan foydalanish orqali siz <strong>@shoptechsbot</strong> litsenziya shartlariga to'liq rozilik bildirasiz.</p>
    </section>

    <section>
        <h3 style="color: #2980b9;">2. Foydalanish Huquqlari</h3>
        <ul>
            <li><strong>Shaxsiy foydalanish:</strong> Tadqiqot, tajriba o'tkazish, shaxsiy o'rganish va hobbi loyihalari.</li>
            <li><strong>Ichki biznes:</strong> Kompaniyangizning ichki operatsiyalari uchun.</li>
            <li><strong>Ilmiy ishlar:</strong> Jamiyat bilimini oshirishga qaratilgan notijoriy izlanishlar.</li>
        </ul>
    </section>

    <section>
        <h3 style="color: #c0392b;">3. Qat'iyan Taqiqlanadi 🚫</h3>
        <ul>
            <li><strong>Tarqatish:</strong> Dasturni boshqalarga tarqatish yoki sotish.</li>
            <li><strong>O'zgartirish:</strong> Dastur kodini o'zgartirish yoki uning asosida yangi mahsulot yaratish.</li>
            <li><strong>Aylanib o'tish (Bypass):</strong> Litsenziya cheklovlarini texnik yo'llar bilan buzish yoki yopiq funksiyalarni ochishga urinish.</li>
        </ul>
    </section>

    <section>
        <h3 style="color: #2980b9;">4. Plaginlar va Interfeyslar</h3>
        <p>Faqat rasmiy interfeyslar orqali plaginlar yaratishga ruxsat beriladi. Litsenziya cheklovlarini chetlab o'tadigan uchinchi tomon plaginlaridan foydalanish litsenziyaning bekor qilinishiga olib keladi.</p>
    </section>

    <section style="background-color: #f9f9f9; padding: 15px; border-left: 5px solid #bdc3c7;">
        <h3 style="margin-top: 0;">5. Javobgarlikning Yo'qligi</h3>
        <p><em>Eslatma: Dastur <strong>"boricha" (As Is)</strong> taqdim etiladi. Litsenziya beruvchi hech qanday zarar yoki texnik nosozliklar uchun javobgar emas.</em></p>
    </section>
</article>

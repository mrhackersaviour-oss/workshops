# OTP Brute Force CTF Lab

Bu CTF (Capture The Flag) musobaqasi uchun tayyorlangan zaif OTP autentifikatsiya tizimi.

## Zaiflik

Bu ilovada quyidagi xavfsizlik zaifliklarini topishingiz kerak:
- **OTP Brute Force**: OTP kod 00-99 oralig'ida (faqat 100 ta variant)
- **Rate Limiting yo'q**: Cheksiz urinishlar mumkin
- **Session-based autentifikatsiya**

## Docker orqali ishga tushirish

### 1. Docker build va run (oddiy usul)
```bash
# Docker image build qilish
docker build -t otp-brute-ctf .

# Containerni ishga tushirish
docker run -d -p 5000:5000 --name otp-brute-ctf otp-brute-ctf

# Loglarni ko'rish
docker logs -f otp-brute-ctf

# To'xtatish
docker stop otp-brute-ctf
docker rm otp-brute-ctf
```

### 2. Docker Compose (tavsiya etiladi)
```bash
# Containerni ishga tushirish
docker-compose up -d

# Loglarni ko'rish
docker-compose logs -f

# To'xtatish
docker-compose down
```

## Ishlatish

1. Brauzerda `http://localhost:5000` manziliga o'ting
2. Login sahifasida "Forgot Password?" tugmasini bosing
3. Admin telefon raqamini kiriting: `+998887174061`
4. OTP kodni brute force qiling (00-99)
5. Flag ni dashboard da topasiz

## Test Credentials

- **Username**: admin
- **Password**: Admin123!
- **Phone**: +998887174061

## CTF Maqsadi

OTP autentifikatsiyani bypass qilib, admin accountiga kirishingiz va flagni topishingiz kerak.

**Flag formati**: `TURAN{...}`

## Portlar

- **Frontend + Backend**: 5000

## Foydalanilgan Texnologiyalar

- Python 3.11
- Flask
- SQLite
- HTML/CSS/JavaScript

## Eslatma

Bu lab faqat ta'lim maqsadida yaratilgan. Real ilovalarni bunday zaif qilmang!

## Muallif

t.me/shoptechsbot

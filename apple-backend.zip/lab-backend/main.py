from uuid import uuid4
from contextlib import asynccontextmanager
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession
from fastapi import FastAPI, Depends
from fastapi.middleware.cors import CORSMiddleware
from database import get_db, User
from utils import create_tokens, get_current_user
from database import init_db


@asynccontextmanager
async def lifespan(app: FastAPI):
    await init_db()
    yield


app = FastAPI(lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


class UserSchema(BaseModel):
    email: str
    first_name: str
    last_name: str
    phone_number: str
    password: str


class LoginSchema(BaseModel):
    email: str
    password: str


@app.post("/submit")
async def submit_form(data: UserSchema, db: AsyncSession = Depends(get_db)):
    session = str(uuid4())

    new_user = User(
        email=data.email,
        first_name=data.first_name,
        last_name=data.last_name,
        phone_number=data.phone_number,
        session=session,
        password=data.password,
    )

    db.add(new_user)
    await db.commit()

    return {"msg": "success", "session": session}


@app.post("/login")
async def login(data: LoginSchema, db: AsyncSession = Depends(get_db)):
    email = data.email
    password = data.password

    result = await db.execute(select(User).where(User.email == email))
    user = result.scalars().first()

    if user is None:
        return {"error": "user not found or password incorrect!"}

    if user.password != password:
        return {"error": "user not found or password incorrect!"}

    access_token = create_tokens({"sub": user.email, "role": user.role})

    return {"access_token": access_token}


@app.get("/dashboard")
async def dashboard(current_user=Depends(get_current_user)):
    return current_user

@app.get("/session={session}")
async def sso_session(session: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(User).where(User.session == session))
    user = result.scalars().first()

    if user is None:
        return {"error": "session invalid"}

    access_token = create_tokens({"sub": user.email, "role": user.role})

    return {"access_token": access_token}
